﻿// Импортируем необходимую библиотеку
using System;

// Определяем класс Date, представляющий дату
class Date
{
    // Поле для хранения дня
    public int Day { get; set; }

    // Поле для хранения месяца
    public int Month { get; set; }

    // Поле для хранения года
    public int Year { get; set; }

    // Конструктор для инициализации объекта класса Date
    public Date(int day, int month, int year)
    {
        // Присваиваем полям значения, переданные в конструктор
        Day = day;
        Month = month;
        Year = year;
    }

    // Определение оператора вычитания для вычисления разницы между двумя объектами класса Date
    public static int operator -(Date date1, Date date2)
    {
        // Преобразуем объекты класса Date в объекты класса DateTime для удобства вычисления разницы
        DateTime dt1 = new DateTime(date1.Year, date1.Month, date1.Day);
        DateTime dt2 = new DateTime(date2.Year, date2.Month, date2.Day);

        // Вычисляем разницу между двумя объектами класса DateTime в днях
        TimeSpan difference = dt1 - dt2;
        return difference.Days;
    }

    // Определение оператора сложения для добавления указанного количества дней к объекту класса Date
    public static Date operator +(Date date, int days)
    {
        // Преобразуем объект класса Date в объект класса DateTime для удобства добавления дней
        DateTime dt = new DateTime(date.Year, date.Month, date.Day);

        // Добавляем указанное количество дней к объекту класса DateTime
        dt = dt.AddDays(days);

        // Создаем новый объект класса Date с обновленными значениями даты
        return new Date(dt.Day, dt.Month, dt.Year);
    }
}

// Определяем класс Program, являющийся точкой входа в программу
class Program
{
    // Определяем метод Main, который выполняется при запуске программы
    static void Main()
    {
        // Создаем два объекта класса Date
        Date date1 = new Date(1, 1, 2024);
        Date date2 = new Date(1, 1, 2023);

        // Вычисляем разницу в днях между двумя объектами класса Date
        int daysDifference = date1 - date2;
        // Выводим разницу в днях на консоль
        Console.WriteLine("Разница в днях между date1 и date2: " + daysDifference);

        // Добавляем 10 дней к первому объекту класса Date
        Date newDate = date1 + 10;
        // Выводим новую дату на консоль
        Console.WriteLine("Дата после добавления 10 дней к date1: " + newDate.Day + "/" + newDate.Month + "/" + newDate.Year);
    }
}

﻿// Импортируем необходимую библиотеку
using System;

// Определяем класс Block для представления блока с четырьмя сторонами
class Block
{
    // Поля для хранения длин сторон блока
    private int side1;
    private int side2;
    private int side3;
    private int side4;

    // Конструктор для инициализации блока
    public Block(int s1, int s2, int s3, int s4)
    {
        // Присваиваем полям значения, переданные в конструктор
        side1 = s1;
        side2 = s2;
        side3 = s3;
        side4 = s4;
    }

    // Переопределяем метод Equals для сравнения блоков по длинам их сторон
    public override bool Equals(object obj)
    {
        // Проверяем, является ли переданный объект блоком и имеет ли он тот же тип, что и текущий блок
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }

        // Приводим переданный объект к типу Block
        Block other = (Block)obj;

        // Сравниваем длины сторон двух блоков
        return side1 == other.side1 && side2 == other.side2 && side3 == other.side3 && side4 == other.side4;
    }

    // Переопределяем метод ToString для вывода информации о блоке в виде строки
    public override string ToString()
    {
        // Возвращаем строку с длинами сторон блока
        return $"Стороны блока: {side1}, {side2}, {side3}, {side4}";
    }
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Создаем три блока
        Block block1 = new Block(1, 2, 3, 4);
        Block block2 = new Block(1, 2, 3, 4);
        Block block3 = new Block(2, 3, 4, 5);

        // Выводим информацию о блоках на консоль
        Console.WriteLine("Блок1: " + block1);
        Console.WriteLine("Блок2: " + block2);
        Console.WriteLine("Блок3: " + block3);

        // Сравниваем блоки и выводим результат на консоль
        Console.WriteLine("Блок1 равен Блок2: " + block1.Equals(block2));
        Console.WriteLine("Блок1 равен Блок3: " + block1.Equals(block3));
    }
}

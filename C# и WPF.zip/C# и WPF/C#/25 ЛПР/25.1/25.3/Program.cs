﻿// Импортируем необходимую библиотеку
using System;

// Определяем класс House для представления дома
class House
{
    // Поле для хранения количества комнат в доме
    public int Rooms { get; set; }

    // Поле для хранения цвета дома
    public string Color { get; set; }

    // Конструктор для инициализации дома
    public House(int rooms, string color)
    {
        // Присваиваем полям значения, переданные в конструктор
        Rooms = rooms;
        Color = color;
    }

    // Метод для поверхностного копирования дома
    public House Clone()
    {
        // Выполняем поверхностное копирование объекта с использованием метода MemberwiseClone
        return this.MemberwiseClone() as House;
    }

    // Метод для глубокого копирования дома
    public House DeepClone()
    {
        // Выполняем глубокое копирование объекта путем создания нового объекта с теми же значениями полей
        return new House(Rooms, Color);
    }
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Создаем оригинальный дом
        House originalHouse = new House(3, "Blue");

        // Выполняем поверхностное копирование оригинального дома
        House clonedHouse = originalHouse.Clone();
        // Изменяем цвет клонированного дома
        clonedHouse.Color = "Red";

        // Выполняем глубокое копирование оригинального дома
        House deepClonedHouse = originalHouse.DeepClone();
        // Изменяем цвет глубоко клонированного дома
        deepClonedHouse.Color = "Green";

        // Выводим информацию о домах на консоль
        Console.WriteLine("Original House: Rooms - " + originalHouse.Rooms + ", Color - " + originalHouse.Color);
        Console.WriteLine("Cloned House: Rooms - " + clonedHouse.Rooms + ", Color - " + clonedHouse.Color);
        Console.WriteLine("Deep Cloned House: Rooms - " + deepClonedHouse.Rooms + ", Color - " + deepClonedHouse.Color);
    }
}

﻿// Импортируем необходимую библиотеку
using System;

// Определяем структуру Point3D для хранения координат точки в трехмерном пространстве
struct Point3D
{
    // Поле для хранения координаты X
    public int X;

    // Поле для хранения координаты Y
    public int Y;

    // Поле для хранения координаты Z
    public int Z;

    // Конструктор для инициализации структуры
    public Point3D(int x, int y, int z)
    {
        // Присваиваем полям значения, переданные в конструктор
        X = x;
        Y = y;
        Z = z;
    }

    // Определяем оператор сложения для сложения двух точек
    public static Point3D operator +(Point3D point1, Point3D point2)
    {
        // Возвращаем новую точку, координаты которой являются суммой координат двух переданных точек
        return new Point3D(point1.X + point2.X, point1.Y + point2.Y, point1.Z + point2.Z);
    }

    // Переопределяем метод ToString() для вывода информации о точке в виде строки
    public override string ToString()
    {
        // Возвращаем строку с координатами точки
        return $"({X}, {Y}, {Z})";
    }
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Создаем две точки
        Point3D point1 = new Point3D(1, 2, 3);
        Point3D point2 = new Point3D(4, 5, 6);

        // Складываем две точки
        Point3D sum = point1 + point2;

        // Выводим на консоль информацию о точках и их сумме
        Console.WriteLine($"Точка1: {point1}");
        Console.WriteLine($"Точка2: {point2}");
        Console.WriteLine($"Сумма Точка1 и Точка2: {sum}");
    }
}

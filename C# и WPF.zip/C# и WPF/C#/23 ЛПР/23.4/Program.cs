﻿// Импортируем необходимые библиотеки
using System;
using System.Collections;
using System.Collections.Generic;

// Определяем статический класс Extensions, который будет содержать методы расширения
static class Extensions
{
    // Определяем метод расширения GetArray для преобразования последовательности в массив
    public static T[] GetArray<T>(this IEnumerable<T> list)
    {
        // Преобразуем последовательность в массив и возвращаем его
        return list.ToArray();
    }
}

// Определяем класс MyList, который реализует интерфейс IEnumerable<T>
class MyList<T> : IEnumerable<T>
{
    // Определяем приватное поле items, которое будет хранить элементы списка
    private List<T> items = new List<T>();

    // Определяем метод Add для добавления элемента в список
    public void Add(T item)
    {
        // Добавляем элемент в список
        items.Add(item);
    }

    // Определяем индексатор для доступа к элементам списка по индексу
    public T this[int index]
    {
        // Возвращаем элемент списка по указанному индексу
        get { return items[index]; }
    }

    // Определяем свойство Count для получения количества элементов в списке
    public int Count
    {
        // Возвращаем количество элементов в списке
        get { return items.Count; }
    }

    // Определяем метод GetEnumerator для перечисления элементов списка
    public IEnumerator<T> GetEnumerator()
    {
        // Возвращаем итератор для перечисления элементов списка
        return items.GetEnumerator();
    }

    // Определяем метод GetEnumerator для реализации интерфейса IEnumerable
    IEnumerator IEnumerable.GetEnumerator()
    {
        // Возвращаем итератор для перечисления элементов списка
        return GetEnumerator();
    }
}

// Определяем класс программы
class Program
{
    // Определяем метод Main, который является точкой входа в программу
    static void Main()
    {
        // Создаем список целых чисел
        MyList<int> myList = new MyList<int>();

        // Добавляем элементы в список
        myList.Add(1);
        myList.Add(2);
        myList.Add(3);

        // Преобразуем список в массив с помощью метода расширения GetArray
        int[] array = myList.GetArray();

        // Выводим на консоль элементы массива
        Console.WriteLine("Values in the array:");
        foreach (var item in array)
        {
            Console.WriteLine(item);
        }
    }
}


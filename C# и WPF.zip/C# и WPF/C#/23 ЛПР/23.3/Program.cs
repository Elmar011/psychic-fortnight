﻿// Импортируем необходимые библиотеки
using System;
using System.Collections;
using System.Collections.Generic;

// Определяем класс словаря MyDictionary, который реализует интерфейс IEnumerable<KeyValuePair<TKey, TValue>>
class MyDictionary<TKey, TValue> : IEnumerable<KeyValuePair<TKey, TValue>>
{
    // Определяем приватное поле items, которое будет хранить элементы словаря
    private List<KeyValuePair<TKey, TValue>> items = new List<KeyValuePair<TKey, TValue>>();

    // Определяем метод Add для добавления элемента в словарь
    public void Add(TKey key, TValue value)
    {
        // Добавляем элемент в словарь
        items.Add(new KeyValuePair<TKey, TValue>(key, value));
    }

    // Определяем индексатор для доступа к элементам словаря по ключу
    public TValue this[TKey key]
    {
        get
        {
            // Ищем элемент словаря по указанному ключу
            var item = items.Find(i => i.Key.Equals(key));

            // Если элемент не найден, выбрасываем исключение KeyNotFoundException
            if (item.Equals(default(KeyValuePair<TKey, TValue>)))
            {
                throw new KeyNotFoundException();
            }

            // Возвращаем значение элемента словаря
            return item.Value;
        }
    }

    // Определяем свойство Count для получения количества элементов в словаре
    public int Count
    {
        // Возвращаем количество элементов в словаре
        get { return items.Count; }
    }

    // Определяем метод GetEnumerator для перечисления элементов словаря
    public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
    {
        // Возвращаем итератор для перечисления элементов словаря
        return items.GetEnumerator();
    }

    // Определяем метод GetEnumerator для реализации интерфейса IEnumerable
    IEnumerator IEnumerable.GetEnumerator()
    {
        // Возвращаем итератор для перечисления элементов словаря
        return GetEnumerator();
    }
}

// Определяем класс программы
class Program
{
    // Определяем метод Main, который является точкой входа в программу
    static void Main()
    {
        // Создаем словарь строк и целых чисел
        MyDictionary<string, int> myDictionary = new MyDictionary<string, int>();

        // Добавляем элементы в словарь
        myDictionary.Add("One", 1);
        myDictionary.Add("Two", 2);
        myDictionary.Add("Three", 3);

        // Перебираем элементы словаря и выводим их на консоль
        foreach (var item in myDictionary)
        {
            Console.WriteLine($"{item.Key}: {item.Value}");
        }

        // Выводим на консоль количество элементов в словаре
        Console.WriteLine($"Total elements: {myDictionary.Count}");

        // Пытаемся получить значение по ключу "Two"
        try
        {
            Console.WriteLine($"Value for key 'Two': {myDictionary["Two"]}");
        }
        // Если ключ не найден, выводим сообщение об ошибке
        catch (KeyNotFoundException)
        {
            Console.WriteLine("Key not found");
        }
    }
}

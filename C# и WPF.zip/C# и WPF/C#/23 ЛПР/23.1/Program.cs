﻿// Импортируем необходимые библиотеки
using System;
using System.Collections.Generic;

// Определяем класс программы
class Program
{
    // Определяем метод Main, который является точкой входа в программу
    static void Main()
    {
        // Создаем массив целых чисел
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        // Получаем коллекцию четных чисел из массива с помощью метода GetEvenNumbers
        var evenNumbers = GetEvenNumbers(numbers);

        // Выводим четные числа на консоль
        foreach (var number in evenNumbers)
        {
            Console.WriteLine(number);
        }
    }

    // Определяем метод для получения коллекции четных чисел
    static IEnumerable<int> GetEvenNumbers(int[] numbers)
    {
        // Перебираем числа в массиве
        foreach (var number in numbers)
        {
            // Если число четное, то возвращаем его с помощью yield return
            if (number % 2 == 0)
            {
                yield return number;
            }
        }
    }
}

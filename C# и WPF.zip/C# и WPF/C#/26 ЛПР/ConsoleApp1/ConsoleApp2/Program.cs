﻿using System; // Импорт пространства имен System
using System.Collections.Generic; // Импорт пространства имен System.Collections.Generic
using System.Linq; // Импорт пространства имен System.Linq

class Car // Объявление класса Car
{
    public string Brand { get; set; } // Объявление свойства Brand типа string
    public string Model { get; set; } // Объявление свойства Model типа string
    public int Year { get; set; } // Объявление свойства Year типа int
    public string Color { get; set; } // Объявление свойства Color типа string
}

class Purchase // Объявление класса Purchase
{
    public string CarModel { get; set; } // Объявление свойства CarModel типа string
    public string BuyerName { get; set; } // Объявление свойства BuyerName типа string
    public string PhoneNumber { get; set; } // Объявление свойства PhoneNumber типа string
}

class Program // Объявление класса Program
{
    static void Main() // Объявление метода Main
    {
        List<Car> cars = new List<Car> // Создание списка cars типа Car
        {
            new Car { Brand = "Toyota", Model = "Camry", Year = 2023, Color = "Grey" }, // Добавление нового объекта Car в список
            new Car { Brand = "Lada", Model = "Vesta", Year = 2021, Color = "Red" }, // Добавление нового объекта Car в список
            new Car { Brand = "Ford", Model = "Focus", Year = 2023, Color = "Black" } // Добавление нового объекта Car в список
        };

        List<Purchase> purchases = new List<Purchase> // Создание списка purchases типа Purchase
        {
            new Purchase { CarModel = "Camry", BuyerName = "Влад", PhoneNumber = "000-000-0000" }, // Добавление нового объекта Purchase в список
            new Purchase { CarModel = "Vesta", BuyerName = "Бекбол", PhoneNumber = "111-111-1111" }, // Добавление нового объекта Purchase в список
            new Purchase { CarModel = "Focus", BuyerName = "Максим", PhoneNumber = "555-555-5555" } // Добавление нового объекта Purchase в список
        };

        Console.WriteLine("Доступные модели:"); // Вывод строки в консоль

        foreach (var car in cars) // Цикл для вывода доступных моделей автомобилей
        {
            Console.WriteLine(car.Model); // Вывод названия модели автомобиля в консоль
        }

        Console.Write("Выберите автомобиль: "); // Вывод строки в консоль и запрос выбора автомобиля

        string selectedModel = Console.ReadLine(); // Чтение введенной пользователем модели автомобиля

        var purchaseInfo = from car in cars // Создание запроса LINQ для получения информации о покупке
                           join purchase in purchases on car.Model equals purchase.CarModel // Присоединение таблиц cars и purchases по полю Model и CarModel
                           where car.Model == selectedModel // Фильтрация по выбранной модели
                           select new // Выборка нового анонимного объекта
                           {
                               BuyerName = purchase.BuyerName, // Присвоение свойства BuyerName из списка purchases
                               CarInfo = car // Присвоение свойства CarInfo из списка cars
                           };

        foreach (var info in purchaseInfo) // Цикл для вывода информации о покупке
        {
            Console.WriteLine($"Покупатель: {info.BuyerName}"); // Вывод имени покупателя
            Console.WriteLine($"Информация о машине: {info.CarInfo.Brand} {info.CarInfo.Model}, {info.CarInfo.Year}, {info.CarInfo.Color}"); // Вывод информации о машине
        }
    }
}

﻿using System; //Подключение пространства имен System, которое содержит основные классы и структуры .NET Framework.

using System.Collections.Generic; //Подключение пространства имен System.Collections.Generic, которое содержит интерфейсы и классы, обеспечивающие удобное хранение коллекций объектов.

class Program //Объявление класса Program.
{
    static void Main() //Объявление статического метода Main, который является входной точкой программы.
    {
        var dictionary = new[] //Создание массива анонимных объектов и инициализация переменной dictionary.
        {
            new { English = "apple", Russian = "яблоко" }, //Инициализация первого анонимного объекта в массиве.
            new { English = "cat", Russian = "кот" }, //Инициализация второго анонимного объекта в массиве и т.д.
            new { English = "house", Russian = "дом" },
            new { English = "sun", Russian = "солнце" },
            new { English = "book", Russian = "книга" },
            new { English = "computer", Russian = "компьютер" },
            new { English = "tree", Russian = "дерево" },
            new { English = "friend", Russian = "друг" },
            new { English = "water", Russian = "вода" },
            new { English = "time", Russian = "время" }
        };

        Console.WriteLine("Англо-Русский словарь:"); //Вывод строки "Англо-Русский словарь:".

        foreach (var word in dictionary) //Начало цикла foreach для перебора элементов массива dictionary.
        {
            Console.WriteLine($"{word.English} - {word.Russian}"); //Вывод значений полей English и Russian каждого объекта в массиве.
        }
    }
}
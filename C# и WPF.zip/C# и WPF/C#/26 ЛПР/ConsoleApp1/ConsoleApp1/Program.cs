﻿using System; //Подключение пространства имен System

class Calculator
{
    public dynamic Add(dynamic a, dynamic b) //Определение метода Add для сложения двух чисел
    {
        return a + b; //Возврат результата сложения
    }

    public dynamic Subtract(dynamic a, dynamic b) //Определение метода Subtract для вычитания двух чисел
    {
        return a - b; //Возврат результата вычитания
    }

    public dynamic Multiply(dynamic a, dynamic b) //Определение метода Multiply для умножения двух чисел
    {
        return a * b; //Возврат результата умножения
    }

    public dynamic Divide(dynamic a, dynamic b) //Определение метода Divide для деления двух чисел
    {
        if (b == 0) //Проверка на деление на ноль
        {
            return "Division by zero is not allowed."; //Возврат сообщения об ошибке
        }
        return a / b; //Возврат результата деления
    }
}

class Program
{
    static void Main()
    {
        Calculator calculator = new Calculator(); //Создание экземпляра класса Calculator

        dynamic result1 = calculator.Add(5, 3); //Вызов метода Add для сложения чисел 5 и 3
        Console.WriteLine("Addition Result: " + result1); //Вывод результата сложения

        dynamic result2 = calculator.Subtract(10.5, 3.2); //Вызов метода Subtract для вычитания чисел 10.5 и 3.2
        Console.WriteLine("Subtraction Result: " + result2); //Вывод результата вычитания

        dynamic result3 = calculator.Multiply(2, 4.5); //Вызов метода Multiply для умножения чисел 2 и 4.5
        Console.WriteLine("Multiplication Result: " + result3); //Вывод результата умножения

        dynamic result4 = calculator.Divide(10, 2); //Вызов метода Divide для деления чисел 10 на 2
        Console.WriteLine("Division Result: " + result4); //Вывод результата деления

        dynamic result5 = calculator.Divide(5, 0); //Вызов метода Divide для деления чисел 5 на 0 (деление на ноль)
        Console.WriteLine("Division Result: " + result5); //Вывод сообщения об ошибке деления на ноль
    }
}
﻿using System;
    class Program
    {
        static void Main(string[] args)
        {
            // Создание экземпляра класса User
            User user = new User("alex.hex", "Alex", "Zhin", 12);

            // Вывод информации о пользователе
            user.DisplayInfo();

            Console.ReadLine();
        }
    }

    class User
    {
    // Поля класса User
    private string login, firstName, lastName;

    private int age;

    private readonly DateTime registrationDate;

        // Конструктор класса User
        public User(string login, string firstName, string lastName, int age)
        {
            this.login = login;
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            this.registrationDate = DateTime.Now;
        }

        // Метод для вывода информации о пользователе
        public void DisplayInfo()
        {
            Console.WriteLine("Login: " + login);
            Console.WriteLine("Name: " + firstName);
            Console.WriteLine("Last Name: " + lastName);
            Console.WriteLine("Age: " + age);
            Console.WriteLine("Registration Date: " + registrationDate);
        }
    }

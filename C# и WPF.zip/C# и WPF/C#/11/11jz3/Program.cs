﻿using System;

class Employee // представляет сотрудника компании с определенными характеристиками.
{
    public string LastName { get; } //// У класса есть свойства LastName, FirstName, Position и Salary для хранения информации о фамилии, имени, должности и зарплате сотрудника.
    public string FirstName { get; }
    public string Position { get; }
    public double Salary { get; }

    public Employee(string lastName, string firstName)
    {
        LastName = lastName; // В первом конструкторе класса инициализируются только фамилия и имя сотрудника.
        FirstName = firstName;
    }

    public Employee(string lastName, string firstName, string position, double salary)
    {
        LastName = lastName;
        FirstName = firstName; //Во втором конструкторе инициализируются фамилия, имя, должность и зарплата сотрудника.
        Position = position;
        Salary = salary;
    }

    public void DisplayInfo() // Метод DisplayInfo() выводит информацию о сотруднике, включая фамилию, имя, должность и зарплату (если они заданы).
    {
        Console.WriteLine("Фамилия: " + LastName);
        Console.WriteLine("Имя: " + FirstName);
        if (!string.IsNullOrEmpty(Position))
            Console.WriteLine("Должность: " + Position);
        if (Salary > 0)
            Console.WriteLine("Оклад: " + Salary);
    }
}

class Program
{
    static void Main() //В методе Main() создаются два объекта класса Employee с различными параметрами - один только с фамилией и именем, другой с указанием также должности и зарплаты.
    {
        Employee employee1 = new Employee("Трофимов", "Иван");
        Employee employee2 = new Employee("Олеговог", "Иван", "Менеджер", 13000.0);

        Console.WriteLine("Информация о сотруднике 1:");
        employee1.DisplayInfo(); //Выводится информация о каждом из сотрудников с помощью метода DisplayInfo().

        Console.WriteLine("\nИнформация о сотруднике 2:");
        employee2.DisplayInfo();

        Console.ReadLine(); // Для задержки закрытия консоли используется метод Console.ReadLine().
    }
}
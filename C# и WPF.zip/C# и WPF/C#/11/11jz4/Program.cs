﻿using System;

class Invoice
{
    // Поля для хранения данных о счете, покупателе и поставщике
    private int account;
    private string customer;
    private string provider;
    private string article;
    private int quantity;

    // Конструктор класса, инициализирует счет, покупателя и поставщика
    public Invoice(int account, string customer, string provider)
    {
        this.account = account;
        this.customer = customer;
        this.provider = provider;
    }

    // Метод для добавления информации о товаре
    public void AddProduct(string article, int quantity)
    {
        this.article = article;
        this.quantity = quantity;
    }

    // Метод для расчета общей стоимости заказа с НДС или без
    public double CalculateTotalPrice(bool withVAT)
    {
        // Задаем стоимость товара и ставку НДС (20%)
        double price = 100.0; // Пример стоимости товара
        double vatRate = 0.20; // Ставка НДС (20%)

        // Рассчитываем общую стоимость без НДС
        double totalWithoutVAT = price * quantity;

        // Рассчитываем общую стоимость с НДС, если withVAT равно true
        double totalWithVAT = withVAT ? totalWithoutVAT * (1 + vatRate) : totalWithoutVAT;

        // Возвращаем общую стоимость с НДС, если withVAT равно true, иначе общую стоимость без НДС
        return withVAT ? totalWithVAT : totalWithoutVAT;
    }
}

class Program
{
    static void Main()
    {
        // Создаем экземпляр класса Invoice и инициализируем данные о счете, покупателе и поставщике
        Invoice invoice = new Invoice(952, "Покупатель", "Поставщик");

        // Добавляем информацию о товаре (название товара и количество)
        invoice.AddProduct("Товар 1", 3);

        // Рассчитываем общую стоимость заказа с НДС и без
        double totalPriceWithVAT = invoice.CalculateTotalPrice(true);
        double totalPriceWithoutVAT = invoice.CalculateTotalPrice(false);

        // Выводим результаты на консоль
        Console.WriteLine("Сумма заказа с НДС: " + totalPriceWithVAT);
        Console.WriteLine("Сумма заказа без НДС: " + totalPriceWithoutVAT);

        Console.ReadLine(); // Для задержки закрытия консоли
    }
}
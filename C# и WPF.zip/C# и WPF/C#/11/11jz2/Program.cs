﻿using System;

class Converter // представляет конвертер валют, который позволяет конвертировать рубли в доллары, евро и наоборот.
{
    private // В конструкторе класса устанавливаются коэффициенты конвертации для доллара, евро и рубля.
    double usd;
    double eur;
    double rub;

    public
    Converter(double usd, double eur, double rub)
    {
        this.usd = usd;
        this.eur = eur;
        this.rub = rub;
    }

    double rubleToUsd(double ruble)
    {
        return ruble * usd;
    }
    // Методы rubleToUsd() и rubleToEur() позволяют конвертировать заданное количество рублей в доллары и евро соответственно.
    double rubleToEur(double ruble)
    {
        return ruble * eur;
    }

    double usdToRuble(double usd)
    {
        return usd / usd;
    }
    // позволяют конвертировать заданное количество долларов и евро в рубли соответственно.
    double eurToRuble(double eur)
    {
        return eur / eur;
    }

    class Dengi // содержит метод Main() для демонстрации работы конвертера валют.
    {
        static void Main()

        {
            Converter converter = new Converter(0.010906, 0.010146, 1);

            double ruble = 1;
            double eur = converter.rubleToEur(ruble);
            double usd = converter.rubleToUsd(ruble);

            Console.WriteLine($"{ruble} рублей равно {usd} USD");
            Console.WriteLine($"{ruble} рублей равно {eur} EUR");

            double usdAmount = 50;
            double rubleFromUSD = converter.rubleToUsd(usdAmount);
            Console.WriteLine($"{usdAmount} рублей равно {rubleFromUSD} USD");

            double eurAmount = 50;
            double rubleFromEUR = converter.rubleToUsd(eurAmount);
            Console.WriteLine($"{eurAmount} рублей равно {rubleFromEUR} EUR");
        }
    }
}
// Создается объект класса Converter с заданными коэффициентами.
// Производятся конвертации рублей в доллары и евро, а также обратные конвертации.
// Результаты конвертаций выводятся на экран.


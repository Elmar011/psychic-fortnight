﻿using System;

class Dictionary<TKey, TValue>
{
    private TKey[] keys; // массив для хранения ключей
    private TValue[] values; // массив для хранения значений
    private int count; // количество элементов в словаре

    public Dictionary() // конструктор, инициализирующий массивы и счетчик
    {
        keys = new TKey[0];
        values = new TValue[0];
        count = 0;
    }

    public void Add(TKey key, TValue value) // метод для добавления элемента в словарь
    {
        Array.Resize(ref keys, count + 1); // изменение размера массива ключей
        Array.Resize(ref values, count + 1); // изменение размера массива значений
        keys[count] = key; // сохранение ключа
        values[count] = value; // сохранение значения
        count++; // увеличение счетчика элементов
    }

    public TValue this[TKey key] // индексатор для получения значения по ключу
    {
        get
        {
            int index = Array.IndexOf(keys, key); // поиск индекса ключа
            if (index != -1)
            {
                return values[index]; // возврат соответствующего значения
            }
            else
            {
                throw new KeyNotFoundException("Key not found"); // выброс исключения, если ключ не найден
            }
        }
    }

    public int Count // свойство для получения количества элементов в словаре
    {
        get
        {
            return count;
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        var dictionary = new Dictionary<int, string>(); // создание экземпляра словаря
        dictionary.Add(1, "One"); // добавление элемента
        dictionary.Add(2, "Two"); // добавление элемента

        Console.WriteLine("Value for key 1: " + dictionary[1]); // вывод значения для ключа 1
        Console.WriteLine("Value for key 2: " + dictionary[2]); // вывод значения для ключа 2
        Console.WriteLine("Total count: " + dictionary.Count); // вывод общего количества элементов
    }
}
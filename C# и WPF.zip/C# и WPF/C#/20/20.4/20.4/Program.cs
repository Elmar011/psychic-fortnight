﻿using System;

public class ArrayList
{
    private object[] items;
    private int count;

    public ArrayList()
    {
        items = new object[4]; // Начальный размер массива
        count = 0;
    }

    public void Add(object item)
    {
        if (count == items.Length)
        {
            Array.Resize(ref items, items.Length * 2); // Увеличиваем массив при необходимости
        }
        items[count] = item;
        count++;
    }

    public object this[int index] // Индексатор для доступа к элементам по индексу
    {
        get
        {
            if (index < 0 || index >= count)  // Проверка допустимости индекса
            {
                throw new IndexOutOfRangeException();  // Выброс исключения, если индекс находится вне диапазона    
            }
            return items[index];
        }
        set
        {
            if (index < 0 || index >= count) // Проверка допустимости индекса
            {
                throw new IndexOutOfRangeException();
            }
            items[index] = value;  // Присвоение нового значения элементу по указанному индексу
        }
    }

    public int Count // Свойство для получения количества элементов в ArrayList
    {
        get { return count; } // Возврат числа элементов
    }
}

class Program // Класс программы
{
    static void Main()   // Метод запуска программы
    {
        ArrayList myArrayList = new ArrayList();  // Создание нового экземпляра ArrayList
        myArrayList.Add(1);   // Добавление элемента в список
        myArrayList.Add("Hello"); // Добавление элемента в список
        myArrayList.Add(3.14); // Добавление элемента в список

        for (int i = 0; i < myArrayList.Count; i++)  // Цикл для перебора элементов списка
        {
            Console.WriteLine(myArrayList[i]); // Вывод элемента списка по индексу
        }
    }
}
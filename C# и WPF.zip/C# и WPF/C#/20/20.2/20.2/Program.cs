﻿using System;

class Car
{
    public string Name { get; set; } // Определение класса Car с двумя свойствами: Name и Year.
    public int Year { get; set; }

public Car(string name, int year)  // Свойство Name типа string для хранения названия автомобиля
    {
        Name = name; // Присваивание значения параметра name свойству Name
        Year = year; // Присваивание значения параметра year свойству Year

    }

    public override string ToString()    // Переопределение метода ToString() для класса Car
    {
        return $"Car: {Name}, Year: {Year}"; // Возвращение строки с информацией о названии и годе выпуска автомобиля
    }
}

class CarCollection<T> // Объявление обобщенного класса CarCollection
{
    private T[] cars; // Приватное поле cars типа T[] для хранения коллекции автомобилей

    public CarCollection()     // Конструктор класса CarCollection, создает пустую коллекцию автомобилей
    {
        cars = new T[0];
    }

    public void AddCar(T car)    // Метод AddCar добавляет автомобиль в коллекцию
    {
        Array.Resize(ref cars, cars.Length + 1);      // Увеличение размера массива cars на 1
        cars[cars.Length - 1] = car;    // Присваивание последнему элементу массива cars значение car
    }

    public T this[int index] // Индексатор this[int index] для доступа к элементам коллекции по индексу
    {
        get { return cars[index]; }
    }

    public int Count  // Свойство Count для получения количества элементов в коллекции
    {
        get { return cars.Length; }
    }

    public void RemoveAllCars()  // Метод RemoveAllCars удаляет все автомобили из коллекции
    {
        cars = new T[0];
    }
}

class Program // Класс Program, содержащий точку входа в программу
{
    static void Main() 
    {
        CarCollection<Car> carCollection = new CarCollection<Car>();    // Создание экземпляра класса CarCollection

        carCollection.AddCar(new Car("Toyota", 2020));  // Добавление трех автомобилей в коллекцию
        carCollection.AddCar(new Car("Honda", 2018));
        carCollection.AddCar(new Car("Ford", 2019));

        Console.WriteLine("Cars in the collection:");  // Вывод на консоль информации о автомобилях в коллекции
        for (int i = 0; i < carCollection.Count; i++)
        {
            Console.WriteLine(carCollection[i]);
        }

        carCollection.RemoveAllCars(); // Удаление всех автомобилей из коллекции

        Console.WriteLine("Removed all cars from the collection. Count: " + carCollection.Count);  // Вывод на консоль информации о количестве автомобилей в коллекции
    }
}
﻿using System;
using System.Collections;

class Program
{
    static void Main() // Определение класса Program с методом Main() входной точкой программы
    {
        ArrayList list = new ArrayList(); // Создание объекта ArrayList для хранения различных типов данных
        list.Add(10);
        list.Add("hello");

        for (int i = 0; i < list.Count; i++) // Добавление элементов типа int и string в список
        {
            if (list[i] is int) // Цикл для перебора элементов списка
            {
                int num = (int)list[i]; // Проверка типа элемента: если это int, то преобразование и вывод числа
                Console.WriteLine(num);
            }
            else if (list[i] is string) // Если это строка, то преобразование и вывод строки
            {
                string str = (string)list[i];
                Console.WriteLine(str);
            }
        }
    }
}
﻿class Article
{// В данном коде определены классы Article и Store для представления информации о товарах и магазине.
    private string productName;
    private string storeName;
    private double price;

    public Article(string productName, string storeName, double price)
    {// Класс Article содержит приватные поля productName (название товара), storeName (название магазина) и price (цена товара). В конструкторе Article(productName, storeName, price) устанавливаются значения этих полей.
        this.productName = productName;
        this.storeName = storeName;
        this.price = price;
    }

    public void PrintInfo()
    {// Метод PrintInfo() класса Article выводит информацию о товаре на консоль: название товара, название магазина и стоимость.
        Console.WriteLine($"Название товара: {productName}");
        Console.WriteLine($"Название магазина: {storeName}");
        Console.WriteLine($"Стоимость товара: {price} $\n");
    }

    public string GetProductName()
    {// Метод GetProductName() возвращает название товара.
        return productName;
    }
}

class Store
{// Класс Store содержит массив статей (articles) и конструктор Store(articles), который инициализирует массив статей.
    private Article[] articles;

    public Store(Article[] articles)
    {
        this.articles = articles;
    }

    public void PrintArticleByIndex(int index)
    {// Метод PrintArticleByIndex(index) класса Store выводит информацию о товаре по его индексу в массиве. Если товар с таким индексом не найден, выводится соответствующее сообщение.
        if (index >= 0 && index < articles.Length)
        {
            articles[index].PrintInfo();
        }
        else
        {
            Console.WriteLine("Товар с таким номером не найден");
        }
    }

    public void PrintArticleByProductName(string productName)
    {// Метод PrintArticleByProductName(productName) класса Store выводит информацию о товаре по его названию. Если товар с таким названием не найден, выводится соответствующее сообщение.
        bool found = false;

        foreach (Article article in articles)
        {
            if (article.GetProductName() == productName)
            {
                article.PrintInfo();
                found = true;
                break;
            }
        }

        if (!found)
        {
            Console.WriteLine("Товар с таким названием не найден");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {// В методе Main создаются объекты класса Article для трех товаров и массив articles из этих объектов. Затем создается объект класса Store с передачей массива articles в конструктор.
        Article article1 = new Article("IPHONE", "AppleStore", 1000);
        Article article2 = new Article("MACBOOK", "AppleStore", 5000);
        Article article3 = new Article("IPAD", "AppleStore", 3000);
        Article[] articles = { article1, article2, article3 };
        // Далее выводятся информации о товарах по индексу(в данном случае 0) и по названию(MACBOOK и IPAD).
        Store store = new Store(articles);

        store.PrintArticleByIndex(0);
        store.PrintArticleByProductName("MACBOOK");
        store.PrintArticleByProductName("IPAD");
    }
}// Код позволяет хранить информацию о товарах и магазинах, а также выводить информацию о товарах по индексу и названию.

﻿class MyMatrix
{// В данном коде определен класс MyMatrix, который представляет собой простую матрицу с возможностью изменения размера и установки/получения значений элементов.
    private int[,] matrix;
    private int rows;
    private int columns;

    public MyMatrix(int rows, int columns)
    {// В классе MyMatrix есть приватные поля matrix, rows и columns, где matrix представляет двумерный массив элементов матрицы, а rows и columns хранят количество строк и столбцов соответственно.
        this.rows = rows;// В конструкторе MyMatrix(rows, columns) создается двумерный массив matrix размером rows x columns.
        this.columns = columns;
        matrix = new int[rows, columns];
    }

    public void Resize(int newRows, int newColumns)
    {// Метод Resize(newRows, newColumns) изменяет размер матрицы на newRows x newColumns, переписывая значения из старой матрицы в новую до минимума числа строк и столбцов в новой матрице. Затем обновляются rows, columns и сама matrix.
        int[,] newMatrix = new int[newRows, newColumns];
        for (int i = 0; i < Math.Min(rows, newRows); i++)
        {
            for (int j = 0; j < Math.Min(columns, newColumns); j++)
            {
                newMatrix[i, j] = matrix[i, j];
            }
        }
        matrix = newMatrix;
        rows = newRows;
        columns = newColumns;
    }

    public void SetValue(int row, int column, int value)
    {// Метод SetValue(row, column, value) устанавливает значение value в ячейку с индексами row и column матрицы.
        matrix[row, column] = value;
    }

    public int GetValue(int row, int column)
    {// Метод GetValue(row, column) возвращает значение из ячейки с индексами row и column матрицы.
        return matrix[row, column];
    }

    public void Print()// Метод Print() выводит матрицу на консоль.
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}

class Program
{
    static void Main(string[] args)
    {// В методе Main создается объект MyMatrix размером 3x3 и заполняется значениями от 1 до 9. Затем матрица выводится на консоль.
        MyMatrix matrix = new MyMatrix(3, 3);
        matrix.SetValue(0, 0, 1);
        matrix.SetValue(0, 1, 2);
        matrix.SetValue(0, 2, 3);
        matrix.SetValue(1, 0, 4);
        matrix.SetValue(1, 1, 5);
        matrix.SetValue(1, 2, 6);
        matrix.SetValue(2, 0, 7);
        matrix.SetValue(2, 1, 8);
        matrix.SetValue(2, 2, 9);
        // После этого происходит изменение размера матрицы на 3x3, добавление значений 11, 12, 13 и вывод матрицы на консоль.
        matrix.Print();

        matrix.Resize(3, 3);
        
        matrix.SetValue(3, 1, 11);
        matrix.SetValue(3, 2, 12);
        matrix.SetValue(3, 3, 13);

        matrix.Print();
    }
}// Код позволяет работать с матрицами, изменять их размер и устанавливать/получать значения элементов.
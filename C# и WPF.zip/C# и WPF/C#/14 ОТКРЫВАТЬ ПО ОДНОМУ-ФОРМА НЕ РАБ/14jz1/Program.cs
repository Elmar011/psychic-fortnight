﻿class Dictionary
{// В данном коде определен класс Dictionary, который представляет собой простой словарь с переводами слов на английский и немецкий языки.
    private string[] key = new string[5];
    private string[] eng = new string[5];
    private string[] nem = new string[5];

    public Dictionary()
    {// В классе Dictionary определены три приватных массива key, eng и nem, содержащие ключевые слова, их переводы на английский и немецкий языки соответственно.
        key[0] = "кузнечик"; eng[0] = "grasshopper"; nem[0] = "Grashupfer";
        key[1] = "дневник"; eng[1] = "diary"; nem[1] = "Tagebuch";
        key[2] = "солнце"; eng[2] = "sun"; nem[2] = "die Sonne";
        key[3] = "яблоко"; eng[3] = "apple"; nem[3] = "Apfel";
        key[4] = "зажигалка"; eng[4] = "lighter"; nem[4] = "Feuerzeug";
    }// В конструкторе класса заполняются эти массивы парами слов и их переводов.

    public string this[string index]
    {// Для класса Dictionary определены два индексатора. Первый индексатор принимает строковый индекс и возвращает строку с переводами слова на английский и немецкий языки.
        get 
        { 
            for (int i = 0; i < key.Length; i++) 
                if (key[i] == index)
                    return key[i] + " - " + eng[i] + " - " + nem[i];

            return string.Format("{0} - нет перевода для этого слова", index);
        }
    }

    public string this[int index]
    {// Второй индексатор принимает целочисленный индекс и возвращает строку с переводами слова на английский и немецкий языки по заданному индексу.

        get
        {
            if (index >= 0 && index < key.Length)
                return key[index] + " - " + eng[index] + " - " + nem[index];
            else
                return "Попытка обращения за пределы массива";
        }
    }
}

class Program
{
    static void Main()// В методе Main() создается объект класса Dictionary. 
    {
        Dictionary dictionary = new Dictionary(); // Сначала пользователю предлагается ввести слово на русском языке, после чего выводится его перевод на английский и немецкий языки с использованием первого индексатора.

        Console.WriteLine(dictionary[Console.ReadLine()]);


        Console.WriteLine(new string('-', 20));

        for (int i = 0; i < 6; i++)// Затем выводятся переводы слов из словаря по заданным индексам с использованием второго индексатора.

        {
            Console.WriteLine(dictionary[i]);
        }
    }
}
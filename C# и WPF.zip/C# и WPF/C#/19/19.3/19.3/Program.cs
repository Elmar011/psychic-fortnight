﻿using System;
using System.Collections.Generic;

class MyDictionary<TKey, TValue>
{
    private List<KeyValuePair<TKey, TValue>> items = new List<KeyValuePair<TKey, TValue>>();

    public void Add(TKey key, TValue value)
    {
        items.Add(new KeyValuePair<TKey, TValue>(key, value)); // Метод Add добавляет новую пару ключ-значение в словарь.
    }

    public TValue this[TKey key] // Индексатор this[TKey key] позволяет получить значение по заданному ключу.Если ключ не найден, будет выброшено исключение KeyNotFoundException.
    {
        get
        {
            foreach (var item in items)
            {
                if (EqualityComparer<TKey>.Default.Equals(item.Key, key))
                {
                    return item.Value;
                }
            }
            throw new KeyNotFoundException();
        }
    }

    public int Count // Свойство Count возвращает количество элементов в словаре.
    {
        get { return items.Count; }
    }
}

class Program
{
    static void Main()
    {
        MyDictionary<string, int> myDict = new MyDictionary<string, int>(); //Класс Program демонстрирует использование MyDictionary для хранения и вывода значений по ключу.

        myDict.Add("One", 1); // добавляются в словарь при помощи метода Add
        myDict.Add("Two", 2);
        myDict.Add("Three", 3);

        Console.WriteLine(myDict["One"]); // Вывод 1
        Console.WriteLine(myDict["Two"]); // Вывод 2
        Console.WriteLine(myDict["Three"]); // Вывод 3

        Console.WriteLine("Тотальные элементы дириктории: " + myDict.Count); //Выходные данные: Всего элементов в словаре: 3
    }
}
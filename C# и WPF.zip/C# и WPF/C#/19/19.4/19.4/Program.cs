﻿using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)  // Создание экземпляра класса MyList для целочисленных значений
        {
            MyList<int> list = new MyList<int>();
            list.Add(1); // Добавление элементов в список
            list.Add(2);
            list.Add(3);
        
                int[] array = list.GetArray();  // Получение массива из списка
            foreach (int item in array)
            {
                Console.WriteLine(item);
            }
        }
    }

    public class MyList<T>
    {
        private T[] array = new T[0]; 

        public void Add(T value)
        {
            Array.Resize(ref array, array.Length + 1); // Здесь создается массив array размером 0, который будет использоваться для хранения элементов добавленных в коллекцию
            array[array.Length - 1] = value;
        }

        public T[] GetArray() // Определение метода GetArray() в классе MyList, который возвращает массив элементов списка
        {
            return array;
        }
    }

    public static class MyListExtensions // Определение статического класса MyListExtensions с методом GetArray<T>, который является методом расширения для класса MyList
    {
        public static T[] GetArray<T>(this MyList<T> list)
        {
            return list.GetArray(); // вызывая метод GetArray() у переданного объекта MyList<T>



























































































































































































        }
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;

class MyList<T> : IEnumerable<T> // Объявление класса MyList<T>, который реализует интерфейс
{
    private List<T> list = new List<T>();

    public void Add(T item) // Метод для добавления элемента в список
    {
        list.Add(item);
    }

    public T this[int index] // Индексатор, позволяющий получить элемент списка по индексу
    {
        get { return list[index]; }
    }

    public int Count // Свойство для получения количества элементов списка
    {
        get { return list.Count; }
    }

    public IEnumerator<T> GetEnumerator()
    {
        return list.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator() // Реализация неявного метода GetEnumerator() интерфейса IEnumerable
    {
        return list.GetEnumerator();
    }
}

class Program
{
    static void Main()
    {
        MyList<int> myList = new MyList<int>();

        myList.Add(1); // Добавление элементов в список
        myList.Add(2);
        myList.Add(3);

        Console.WriteLine("Count: " + myList.Count);  // Вывод количества элементов списка

        for (int i = 0; i < myList.Count; i++)  // Вывод элементов списка с помощью цикла
        {
            Console.WriteLine("Element at index " + i + ": " + myList[i]);
        }
    }
}
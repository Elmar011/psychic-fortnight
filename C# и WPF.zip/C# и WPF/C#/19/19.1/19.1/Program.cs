﻿using System;

class MyClass<T>
{
    public static T FactoryMethod()
    {
        return default(T); // Метод FactoryMethod возвращает значение по умолчанию для типа T
    }
}

class Program
{
    static void Main(string[] args)
    {
        int intValue = MyClass<int>.FactoryMethod(); // Создание переменной intValue типа int и присвоение ей значения, возвращаемого методом FactoryMethod int intValue = MyClass<int>.FactoryMethod();
        string stringValue = MyClass<string>.FactoryMethod(); // Создание переменной stringValue типа string и присвоение ей значения, возвращаемого методом FactoryMethod string stringValue = MyClass<string>.FactoryMethod();

        Console.WriteLine($"intValue: {intValue}");  // Вывод значения переменной intValue на консоль
        Console.WriteLine($"stringValue: {stringValue}"); // Вывод значения переменной stringValue на консоль
    }
}
﻿// Задание 1
using System;

class Program
{// Пользователю предлагается ввести дату своего рождения.Затем создается объект DateTime для дня следующего рождения в текущем году. Если этот день уже прошел в текущем году, то к дате следующего рождения добавляется еще один год.Далее вычисляется количество дней до этой даты и выводится на экран.
    static void Main()
    {
        Console.Write("Введите дату вашего рождения (гггг-мм-дд): ");
        DateTime деньРождения = DateTime.Parse(Console.ReadLine());

        DateTime следующееДнюшкоРождения = new DateTime(DateTime.Now.Year, деньРождения.Month, деньРождения.Day);

        if (DateTime.Now > следующееДнюшкоРождения)
        {
            следующееДнюшкоРождения = следующееДнюшкоРождения.AddYears(1);
        }

        int днейДоДняРождения = (int)(следующееДнюшкоРождения - DateTime.Now).TotalDays;

        Console.WriteLine($"До вашего следующего дня рождения осталось {днейДоДняРождения} дней.");
    }
}

// Задание 2
         using System;

         public static class ColorPrinter
{// Пользователю предлагается ввести строку и выбрать цвет текста для ее отображения. В методе Print класса ColorPrinter строка выводится в выбранном цвете. 
    public enum Цвета
    {
        Красный,
        Зеленый,
        Синий,
        Желтый,
        Белый
    }

    public static void Print(string строка, int цвет)
    {
        ConsoleColor выбранныйЦвет = (ConsoleColor)цвет;

        Console.ForegroundColor = выбранныйЦвет;
        Console.WriteLine(строка);
        Console.ResetColor();
    }
}

  class Program
{
       static void Main()
    {
        Console.Write("Введите строку: ");
        string введеннаяСтрока = Console.ReadLine();

        Console.WriteLine("Выберите цвет:");
        Console.WriteLine("1. Красный");
        Console.WriteLine("2. Зеленый");
        Console.WriteLine("3. Синий");
        Console.WriteLine("4. Желтый");
        Console.WriteLine("5. Белый");

        int выбранныйЦвет = int.Parse(Console.ReadLine());

        ColorPrinter.Print(введеннаяСтрока, выбранныйЦвет);
    }
}

// Задание 3
using System;
        
       public enum Должности
{// Пользователю предлагается выбрать должность из перечисления Должности и ввести количество отработанных часов. Метод AskForBonus класса Accountant проверяет, превысил ли сотрудник заданное количество отработанных часов для данной должности. В зависимости от результатов проверки выводится сообщение о предоставлении или непредоставлении премии.
    Менеджер = 160,
    Разработчик = 180,
    Тестировщик = 150
}

public class Accountant
{
    public bool AskForBonus(Должности должность, int отработанныеЧасы)
    {
        return отработанныеЧасы > (int)должность;
    }
}

class Program
{
    static void Main()
    {
        Accountant бухгалтер = new Accountant();

        Console.WriteLine("Выберите должность:");
        Console.WriteLine("1. Менеджер");
        Console.WriteLine("2. Разработчик");
        Console.WriteLine("3. Тестировщик");

        int выбраннаяДолжность = int.Parse(Console.ReadLine());

        Должности должность = (Должности)выбраннаяДолжность;

        Console.Write("Введите количество отработанных часов: ");
        int отработанныеЧасы = int.Parse(Console.ReadLine());

        bool даватьПремию = бухгалтер.AskForBonus(должность, отработанныеЧасы);

        if (даватьПремию)
        {
            Console.WriteLine("Сотруднику положена премия.");
        }
        else
        {
            Console.WriteLine("Сотруднику премию не давать.");
        }
    }
}// Все решения выполнены с использованием структур, перечислений и статических методов, что делает код более удобным и модульным.
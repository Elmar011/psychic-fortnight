﻿using System;

namespace AverageCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Func<int, int, int, double> averageCalculator = delegate (int a, int b, int c)
            {
                return (a + b + c) / 3.0; // Рассчитываем среднее арифметическое
            };

            int num1 = 18; // Объявляем переменную "num1" типа "int" и присваиваем ей значение 18.
            int num2 = 28;
            int num3 = 48;

            double average = averageCalculator(num1, num2, num3); // Вызываем делегат "averageCalculator", передавая в него значения переменных "num1", "num2" и "num3".
                                                                  // Результат расчета среднего арифметического присваиваем переменной "average" типа "double"

            Console.WriteLine($"Среднее арифметическое чисел {num1}, {num2}, {num3} равно {average}");
        }
    }
}
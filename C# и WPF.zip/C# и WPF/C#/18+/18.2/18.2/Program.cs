﻿using System;

namespace LambdaExpressions
{
    class Program
    {
        static void Main(string[] args)
        {
            Func<double, double, double> Add = (a, b) => a + b; // Создаем четыре делегата типа Func<double, double, double>, 
                                                                   // каждый из которых принимает два аргумента типа double и возвращает значение типа double.
            Func<double, double, double> Sub = (a, b) => a - b;
            Func<double, double, double> Mul = (a, b) => a * b;
            Func<double, double, double> Div = (a, b) =>
            {
                if (b == 0)
                {
                    Console.WriteLine("Division by zero is not allowed");
                    return Double.NaN;
                }
                else
                {
                    return a / b;
                }
            };

            Console.Write("Enter the first number: ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the second number: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Choose an operation:"); // Вывод информации на экран
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Sub");
            Console.WriteLine("3. Mul");
            Console.WriteLine("4. Div");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Result: {Add(num1, num2)}"); // математических операций сложения, вычитания, умножения и деления 
                    break;
                case 2:
                    Console.WriteLine($"Result: {Sub(num1, num2)}");
                    break;
                case 3:
                    Console.WriteLine($"Result: {Mul(num1, num2)}");
                    break;
                case 4:
                    Console.WriteLine($"Result: {Div(num1, num2)}");
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }
    }
}
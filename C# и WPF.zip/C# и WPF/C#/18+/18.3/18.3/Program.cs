﻿using System;

namespace AnonymousMethodExample
{
    class Program
    {
        delegate int MyDelegate(); // делегат

        static void Main(string[] args)
        {
            MyDelegate[] delegatesArray = new MyDelegate[3]; // массив делегатов

            // инициализация делегатов
            delegatesArray[0] = delegate { return new Random().Next(1, 51); }; // возвращает случайное значение от 1 до 50
            delegatesArray[1] = delegate { return new Random().Next(1, 101); }; // возвращает случайное значение от 1 до 100
            delegatesArray[2] = delegate { return new Random().Next(1, 21); }; // возвращает случайное значение от 1 до 20

            Console.WriteLine($"Среднее арифметическое: {CalculateAverage(delegatesArray)}");
        }

        static double CalculateAverage(MyDelegate[] delegatesArray)
        {
            int sum = 0;
            foreach (var method in delegatesArray)
            {
                sum += method(); // вызываем каждый метод и суммируем результаты
            }

            return (double)sum / delegatesArray.Length; // возвращаем среднее значение
        }
    }
}
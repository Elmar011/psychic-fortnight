﻿using System;

// Базовый абстрактный класс AbstractHandler
abstract class AbstractHandler
{
    public abstract void Open();
    public abstract void Create();
    public abstract void Change();
    public abstract void Save();
}

// Производный класс XMLHandler
class XMLHandler : AbstractHandler
{
    public override void Open()
    {
        Console.WriteLine("Открыт документ XML");
        Console.WriteLine("Создан новый документ XML");
        Console.WriteLine("Изменен документ XML");
        Console.WriteLine("Сохранен документ XML");
    }
}

// Производный класс TXTHandler
class TXTHandler : AbstractHandler
{
    public override void Open()
    {
        Console.WriteLine("Открыт документ TXT");
        Console.WriteLine("Создан новый документ TXT");
        Console.WriteLine("Изменен документ TXT");
        Console.WriteLine("Сохранен документ TXT");
}

// Производный класс DOCHandler
class DOCHandler : AbstractHandler
{
    public override void Open()
        {
            Console.WriteLine("Открыт документ DOC");
            Console.WriteLine("Создан новый документ DOC");
            Console.WriteLine("Изменен документ DOC");
            Console.WriteLine("Сохранен документ DOC");
        }
}

class Program
{
    static void Main(string[] args)
    {
        // Создаем экземпляры различных форматов документов
        AbstractHandler handler1 = new XMLHandler();
        AbstractHandler handler2 = new TXTHandler();
        AbstractHandler handler3 = new DOCHandler();

        // Выполняем различные операции с документами
        Console.WriteLine("Работа с документом в формате XML:");
        handler1.Create();
        handler1.Open();
        handler1.Change();
        handler1.Save();

        Console.WriteLine("\nРабота с документом в формате TXT:");
        handler2.Create();
        handler2.Open();
        handler2.Change();
        handler2.Save();

        Console.WriteLine("\nРабота с документом в формате DOC:");
        handler3.Create();
        handler3.Open();
        handler3.Change();
        handler3.Save();
    }
}

﻿using System;

// Интерфейс для проигрывания аудио
interface IPlayable
{
    // Метод для начала воспроизведения
    void Play();

    // Метод для приостановки воспроизведения
    void Pause();

    // Метод для остановки воспроизведения
    void Stop();
}

// Интерфейс для записи аудио
interface IRecodable
{
    // Метод для начала записи
    void Record();

    // Метод для приостановки записи
    void Pause();

    // Метод для остановки записи
    void Stop();
}

// Производный класс Player, который реализует оба интерфейса
class Player : IPlayable, IRecodable
{
    // Реализация метода для начала воспроизведения
    public void Play()
    {
        Console.WriteLine("Воспроизведение аудио");
        Console.WriteLine("Запись аудио");
        Console.WriteLine("Пауза");
        Console.WriteLine("Остановка");
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Создаем экземпляр класса Player
        Player player = new Player();

        // Проигрывание
        Console.WriteLine("Проигрывание:");
        player.Play(); // Начинаем воспроизведение
        player.Pause(); // Приостанавливаем воспроизведение
        player.Stop(); // Останавливаем воспроизведение

        // Запись
        Console.WriteLine("\nЗапись:");
        player.Record(); // Начинаем запись
        player.Pause(); // Приостанавливаем запись
        player.Stop(); // Останавливаем запись
    }
}

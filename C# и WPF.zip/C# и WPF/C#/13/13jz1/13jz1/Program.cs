﻿using System;

// Создаем абстрактный класс DocumentPart (часть документа)
abstract class DocumentPart
{
    // Свойство для хранения содержимого части документа
    public string Content { get; set; }

    // Конструктор для инициализации содержимого
    public DocumentPart(string content)
    {
        Content = content;
    }

    // Абстрактный метод для вывода содержимого на экран
    public abstract void Print();
}

// Производный класс Title (заголовок) от DocumentPart
class Title : DocumentPart
{
    // Конструктор передает содержимое базовому классу
    public Title(string content) : base(content) { }

    // Реализация метода для вывода заголовка
    public override void Print()
    {
        Console.WriteLine("Заголовок: " + Content);
    }
}

// Производный класс Body (текст) от DocumentPart
class Body : DocumentPart
{
    // Конструктор передает содержимое базовому классу
    public Body(string content) : base(content) { }

    // Реализация метода для вывода текста
    public override void Print()
    {
        Console.WriteLine("Текст: " + Content);
    }
}

// Производный класс Footer (подвал) от DocumentPart
class Footer : DocumentPart
{
    // Конструктор передает содержимое базовому классу
    public Footer(string content) : base(content) { }

    // Реализация метода для вывода подвала
    public override void Print()
    {
        Console.WriteLine("Подвал: " + Content);
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Создаем экземпляры различных частей документа
        DocumentPart title = new Title("Заголовок документа");
        DocumentPart body = new Body("Это основное содержание документа.");
        DocumentPart footer = new Footer("Страница 1 из 1");

        // Вызываем метод Print() для каждой части документа
        title.Print();
        body.Print();
        footer.Print();
    }
}

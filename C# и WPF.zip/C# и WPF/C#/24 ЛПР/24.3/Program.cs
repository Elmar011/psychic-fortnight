﻿// Импортируем необходимую библиотеку
using System;

// Определяем структуру Price для хранения данных о товаре
struct Price
{
    // Поле для хранения названия товара
    public string productName;

    // Поле для хранения названия магазина
    public string storeName;

    // Поле для хранения цены товара
    public double price;
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Создаем массив для хранения данных о товарах
        Price[] prices = new Price[2];

        // Цикл для ввода данных о товарах с клавиатуры
        for (int i = 0; i < prices.Length; i++)
        {
            // Выводим на консоль запрос данных о товаре
            Console.WriteLine($"Введите информацию о продукте {i + 1}:");

            // Запрашиваем и сохраняем название товара
            Console.Write("Имя продукта: ");
            prices[i].productName = Console.ReadLine();

            // Запрашиваем и сохраняем название магазина
            Console.Write("Название магазина: ");
            prices[i].storeName = Console.ReadLine();

            // Запрашиваем и сохраняем цену товара
            Console.Write("Стоимость в гривнах: ");
            prices[i].price = double.Parse(Console.ReadLine());
        }

        // Сортируем массив по названиям магазинов
        Array.Sort(prices, (x, y) => string.Compare(x.storeName, y.storeName));

        // Запрашиваем название магазина для отображения товаров
        Console.Write("Введите название магазина, чтобы отобразить товары: ");
        string storeToFind = Console.ReadLine();

        // Флаг для проверки, был ли найден магазин
        bool storeFound = false;

        // Перебираем массив товаров
        foreach (var price in prices)
        {
            // Если название магазина совпадает с введенным, выводим информацию о товаре
            if (price.storeName == storeToFind)
            {
                Console.WriteLine($"Имя продукта: {price.productName}");
                Console.WriteLine($"Цена: {price.price} UAH");
                storeFound = true;
            }
        }

        // Если магазин не найден, выводим сообщение об ошибке
        if (!storeFound)
        {
            Console.WriteLine("Ошибка: магазин не найден.");
        }
    }
}

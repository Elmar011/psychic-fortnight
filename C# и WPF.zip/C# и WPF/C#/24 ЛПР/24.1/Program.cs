﻿// Импортируем необходимую библиотеку
using System;

// Определяем класс Calculator, который будет выполнять арифметические операции
class Calculator
{
    // Определяем метод Add для сложения двух чисел
    public int Add(int a, int b)
    {
        // Возвращаем сумму двух чисел
        return a + b;
    }

    // Определяем метод Sub для вычитания двух чисел
    public int Sub(int a, int b)
    {
        // Возвращаем разность двух чисел
        return a - b;
    }

    // Определяем метод Mul для умножения двух чисел
    public int Mul(int a, int b)
    {
        // Возвращаем произведение двух чисел
        return a * b;
    }

    // Определяем метод Div для деления двух чисел
    public int Div(int a, int b)
    {
        // Проверяем, не равно ли второе число нулю
        if (b == 0)
        {
            // Если второе число равно нулю, то вызываем исключение DivideByZeroException
            throw new DivideByZeroException("Делить на 0 нельзя");
        }

        // Возвращаем частное от деления двух чисел
        return a / b;
    }
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Создаем объект класса Calculator
        Calculator calculator = new Calculator();

        try
        {
            // Запрашиваем у пользователя первое число
            Console.Write("Введите первое число: ");
            int num1 = int.Parse(Console.ReadLine());

            // Запрашиваем у пользователя второе число
            Console.Write("Введите второе число: ");
            int num2 = int.Parse(Console.ReadLine());

            // Выводим на консоль список доступных операций
            Console.WriteLine("Select operation: ");
            Console.WriteLine("1. Сложение");
            Console.WriteLine("2. Вычитание");
            Console.WriteLine("3. Умножение");
            Console.WriteLine("4. Деление");

            // Запрашиваем у пользователя номер операции
            int choice = int.Parse(Console.ReadLine());

            // Определяем результат операции
            int result = 0;

            // Выполняем операцию в зависимости от выбора пользователя
            switch (choice)
            {
                case 1:
                    // Выполняем сложение
                    result = calculator.Add(num1, num2);
                    break;
                case 2:
                    // Выполняем вычитание
                    result = calculator.Sub(num1, num2);
                    break;
                case 3:
                    // Выполняем умножение
                    result = calculator.Mul(num1, num2);
                    break;
                case 4:
                    // Выполняем деление
                    result = calculator.Div(num1, num2);
                    break;
                default:
                    // Выводим на консоль сообщение о неверном выборе
                    Console.WriteLine("Неверное значение.");
                    break;
            }

            // Выводим на консоль результат операции
            Console.WriteLine("Результат: " + result);
        }
        catch (FormatException)
        {
            // Выводим на консоль сообщение о некорректном вводе числа
            Console.WriteLine("Введите корректное число");
        }
        catch (DivideByZeroException ex)
        {
            // Выводим на консоль сообщение об ошибке деления на 0
            Console.WriteLine("Ошибка: " + ex.Message);
        }
        catch (Exception ex)
        {
            // Выводим на консоль сообщение об общей ошибке
            Console.WriteLine("Произошла ошибка: " + ex.Message);
        }
    }
}

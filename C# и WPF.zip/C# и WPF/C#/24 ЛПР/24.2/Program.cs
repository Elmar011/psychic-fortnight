﻿// Импортируем необходимые библиотеки
using System;

// Определяем структуру Worker для хранения данных о работнике
struct Worker
{
    // Поле для хранения имени работника
    public string FullName;

    // Поле для хранения должности работника
    public string Position;

    // Поле для хранения года поступления на работу
    public int YearHired;
}

// Определяем класс Program, который будет являться точкой входа в программу
class Program
{
    // Определяем метод Main, который будет выполняться при запуске программы
    static void Main()
    {
        // Массив для хранения данных о работниках
        Worker[] workers = new Worker[3];

        // Цикл для заполнения массива данными о работниках цеез инкремент
        for (int i = 0; i < workers.Length; i++)
        {
            // Выводим на консоль запрос данных о работнике
            Console.WriteLine($"Введите данные для работника {i + 1}:");

            // Запрашиваем и сохраняем имя работника
            Console.Write("ФИО: ");
            string fullName = Console.ReadLine();

            // Запрашиваем и сохраняем должность работника
            Console.Write("Название должности: ");
            string position = Console.ReadLine();

            // Запрашиваем и сохраняем год поступления на работу
            int yearHired;
            while (true)
            {
                Console.Write("Год поступления на работу: ");
                if (!int.TryParse(Console.ReadLine(), out yearHired))
                {
                    Console.WriteLine("Некорректный формат года, попробуйте снова.");
                }
                else
                {
                    break;
                }
            }

            // Заполняем данные о работнике в массиве
            workers[i] = new Worker
            {
                FullName = fullName,
                Position = position,
                YearHired = yearHired
            };
        }

        // Сортируем массив по имени работника в алфавитном порядке
        Array.Sort(workers, (x, y) => string.Compare(x.FullName, y.FullName));

        // Запрашиваем количество лет для сравнения
        Console.Write("Введите количество лет для сравнения: ");
        int yearsToCompare = int.Parse(Console.ReadLine());

        // Выводим на консоль работников с опытом работы, превышающим введенное значение
        Console.WriteLine("Работники с опытом работы, превышающим введенное значение:");
        foreach (var worker in workers)
        {
            // Выводим на консоль имя работника, если его опыт работы превышает введенное значение
            if ((DateTime.Now.Year - worker.YearHired) > yearsToCompare)
            {
                Console.WriteLine(worker.FullName);
            }
        }
    }
}

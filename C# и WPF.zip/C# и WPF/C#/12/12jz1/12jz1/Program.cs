﻿using System;

// Базовый класс Printer
class Printer
{
    // Виртуальный метод для вывода текста
    public virtual void Print(string value)
    {
        Console.WriteLine(value);
    }
}

// Производный класс RedPrinter
class RedPrinter : Printer
{
    // Переопределение метода Print для установки красного цвета
    public override void Print(string value)
    {
        Console.ForegroundColor = ConsoleColor.Red; // Установка цвета текста в красный
        base.Print(value); // Вызов метода Print базового класса
        Console.ResetColor(); // Сброс цвета текста после вывода
    }
}

// Производный класс GreenPrinter
class GreenPrinter : Printer
{
    // Переопределение метода Print для установки зеленого цвета
    public override void Print(string value)
    {
        Console.ForegroundColor = ConsoleColor.Green; // Установка цвета текста в зеленый
        base.Print(value); // Вызов метода Print базового класса
        Console.ResetColor(); // Сброс цвета текста после вывода
    }
}

class Program
{
    static void Main(string[] args)
    {
        Printer defaultPrinter = new Printer(); // Создание экземпляра базового класса Printer
        RedPrinter redPrinter = new RedPrinter(); // Создание экземпляра класса RedPrinter
        GreenPrinter greenPrinter = new GreenPrinter(); // Создание экземпляра класса GreenPrinter

        Console.WriteLine("Default Printer:");
        defaultPrinter.Print("Это сообщение стандарт"); // Вызов метода Print базового класса

        Console.WriteLine("\nRed Printer:");
        redPrinter.Print("Это красное"); // Вызов метода Print класса RedPrinter

        Console.WriteLine("\nGreen Printer:");
        greenPrinter.Print("Это зеленое"); // Вызов метода Print класса GreenPrinter
        Console.ReadKey();
    }
}

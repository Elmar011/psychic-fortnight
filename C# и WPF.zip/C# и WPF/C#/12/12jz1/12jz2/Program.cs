﻿using System;

// Базовый класс Pupil
class Pupil
{
    public virtual void Study()
    {
        Console.WriteLine("Ученик учится");
    }
    //// Базовый класс Pupil содержит виртуальные методы Study(), Read(), Write() и Relax(), которые описывают действия ученика при обучении, чтении, письме и отдыхе соответственно.
    public virtual void Read()
    {
        Console.WriteLine("Ученик читает");
    }

    public virtual void Write()
    {
        Console.WriteLine("Ученик пишет");
    }

    public virtual void Relax()
    {
        Console.WriteLine("Ученик отдыхает");
    }
}

// Производный класс ExcelentPupil
class ExcelentPupil : Pupil
{//// У каждого производного класса (ExcelentPupil, GoodPupil, BadPupil) переопределен метод Study() с описанием поведения каждого типа ученика при учебе
    public override void Study()
    {
        Console.WriteLine("Отличник учится очень хорошо");
    }
}

// Производный класс GoodPupil
class GoodPupil : Pupil
{
    public override void Study()
    {
        Console.WriteLine("Хороший ученик учится хорошо");
    }
}

// Производный класс BadPupil
class BadPupil : Pupil
{
    public override void Study()
    {
        Console.WriteLine("Не очень хороший ученик учится плохо");
    }
}

// Класс ClassRoom
class ClassRoom
{//Класс ClassRoom представляет классную комнату с учениками. 
    private Pupil pupil1;
    private Pupil pupil2;
    private Pupil pupil3; //Конструкторы класса ClassRoom принимают разное количество учеников и инициализируют их.
    private Pupil pupil4;

    public ClassRoom(Pupil pupil1, Pupil pupil2)
    {
        this.pupil1 = pupil1;
        this.pupil2 = pupil2;
    }

    public ClassRoom(Pupil pupil1, Pupil pupil2, Pupil pupil3)
        : this(pupil1, pupil2)
    {
        this.pupil3 = pupil3;
    }

    public ClassRoom(Pupil pupil1, Pupil pupil2, Pupil pupil3, Pupil pupil4)
        : this(pupil1, pupil2, pupil3)
    {
        this.pupil4 = pupil4;
    }

    public void ClassActivities()
    {//Метод ClassActivities() выводит на экран активности учеников в классе, вызывая их методы Study(), Read(), Write(), Relax().
        Console.WriteLine("Активности учеников в классе:");
        pupil1.Study();
        pupil1.Read();
        pupil1.Write();
        pupil1.Relax();
        Console.WriteLine("");
        pupil2.Study();
        pupil2.Read();
        pupil2.Write();
        pupil2.Relax();
        Console.WriteLine("");
        if (pupil3 != null)
        {
            pupil3.Study();
            pupil3.Read();
            pupil3.Write();
            pupil3.Relax();
        }
        if (pupil4 != null)
        {
            pupil4.Study();
            pupil4.Read();
            pupil4.Write();
            pupil4.Relax();
            Console.WriteLine("");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {// В методе Main() создаются ученики различных типов (ExcelentPupil, GoodPupil, BadPupil) и добавляются в объект класса ClassRoom.
        Pupil pupil1 = new ExcelentPupil();
        Pupil pupil2 = new GoodPupil();
        Pupil pupil3 = new BadPupil();
        Pupil pupil4 = new ExcelentPupil();

        ClassRoom classroom = new ClassRoom(pupil1, pupil2, pupil3, pupil4);
        classroom.ClassActivities(); //Затем вызывается метод ClassActivities(), который выводит активности учеников на экран.
    }
}// Объекты классов ExcelentPupil, GoodPupil, BadPupil отражают различные способы учебы и поведения учеников в классе.

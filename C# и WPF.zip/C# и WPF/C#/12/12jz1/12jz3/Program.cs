﻿using System;

// Базовый класс Vehicle
class Vehicle
{
    public double Price { get; set; }
    public double Speed { get; set; }
    public int YearOfManufacture { get; set; }
    public double PriceInUSD { get; set; }

    // Конструктор для Vehicle
    public Vehicle(double price, double speed, int year, double priceInUSD)
    {
        Price = price;
        Speed = speed;
        YearOfManufacture = year;
        PriceInUSD = priceInUSD;
    }

    public virtual void ShowInfo()
    {
        Console.WriteLine("Средство передвижения");
        Console.WriteLine("Цена: {0:C}", Price, PriceInUSD);
        Console.WriteLine("Скорость: {0} км/ч", Speed);
        Console.WriteLine("Год выпуска: {0}", YearOfManufacture);
    }
}

// Производный класс Plane (самолет)
class Plane : Vehicle
{
    public double Altitude { get; set; }
    public int Passengers { get; set; }

    // Конструктор для Plane
    public Plane(double price, double speed, int year, double priceInUSD, double altitude, int passengers)
        : base(price, speed, year, priceInUSD)
    {
        Altitude = altitude;
        Passengers = passengers;
    }

    public override void ShowInfo()
    {
        base.ShowInfo();
        Console.WriteLine("Тип - Самолет");
        Console.WriteLine("Высота: {0} м", Altitude);
        Console.WriteLine("Количество пассажиров: {0}", Passengers);
        Console.WriteLine("---------------------------------------------");
    }
}

// Производный класс Car (автомобиль)
class Car : Vehicle
{
    public string Model { get; set; }

    // Конструктор для Car
    public Car(double price, double speed, int year, double priceInUSD, string model)
        : base(price, speed, year, priceInUSD)
    {
        Model = model;
    }

    public override void ShowInfo()
    {
        base.ShowInfo();
        Console.WriteLine("Тип - Автомобиль");
        Console.WriteLine("Модель: {0}", Model);
        Console.WriteLine("---------------------------------------------");
    }
}

// Производный класс Ship (корабль)
class Ship : Vehicle
{
    public int Passengers { get; set; }
    public string HomePort { get; set; }

    // Конструктор для Ship
    public Ship(double price, double speed, int year, double priceInUSD, int passengers, string homePort)
        : base(price, speed, year, priceInUSD)
    {
        Passengers = passengers;
        HomePort = homePort;
    }

    public override void ShowInfo()
    {
        base.ShowInfo();
        Console.WriteLine("Тип - Корабль");
        Console.WriteLine("Количество пассажиров: {0}", Passengers);
        Console.WriteLine("Порт приписки: {0}", HomePort);
        Console.WriteLine("---------------------------------------------");
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Создаем экземпляры различных транспортных средств
        Vehicle vehicle = new Vehicle(50000, 100, 2020, 4000000);
        Plane plane = new Plane(1000000, 900, 2020, 80000000, 10000, 150);
        Car car = new Car(50000, 150, 2022, 2500000, "Внедоррожник");
        Ship ship = new Ship(2000000, 40, 2019, 150000000, 500, "Мурманск");

        // Выводим информацию о каждом транспортном средстве
        vehicle.ShowInfo();
        Console.WriteLine();
        plane.ShowInfo();
        Console.WriteLine();
        car.ShowInfo();
        Console.WriteLine();
        ship.ShowInfo();
    }
}

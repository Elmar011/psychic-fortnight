﻿using System;

// Задание 1
// Определение структуры Notebook с полями: модель, производитель, цена.
struct Notebook
{
    public string Модель;
    public string Производитель;
    public double Цена;

    // Конструктор для инициализации полей.
    public Notebook(string модель, string производитель, double цена)
    {
        Модель = модель;
        Производитель = производитель;
        Цена = цена;
    }

    // Метод для вывода информации на экран.
    public void ВывестиИнформацию()
    {
        Console.WriteLine($"Модель: {Модель}, Производитель: {Производитель}, Цена: {Цена:C}");
    }
}

// Задание 2
// Определение структуры Train для хранения информации о поездах.
struct Train
{
    public string Название;
    public int НомерПоезда;
    public DateTime ВремяОтправления;

    // Конструктор для инициализации полей.
    public Train(string название, int номерПоезда, DateTime времяОтправления)
    {
        Название = название;
        НомерПоезда = номерПоезда;
        ВремяОтправления = времяОтправления;
    }
}

class Program
{
    static void Main()
    {
        // Задание 2
        // Инициализация массива поездов.
        Train[] поезда = new Train[8];

        Console.WriteLine("Введите данные поездов:");

        // Ввод данных о поездах с клавиатуры и их сохранение в массив.
        for (int i = 0; i < 8; i++)
        {
            Console.Write($"Поезд {i + 1}:\nНазвание: ");
            string название = Console.ReadLine();

            Console.Write("Номер поезда: ");
            int номерПоезда = int.Parse(Console.ReadLine());

            Console.Write("Время отправления (гггг-мм-дд чч:мм): ");
            DateTime времяОтправления = DateTime.Parse(Console.ReadLine());

            поезда[i] = new Train(название, номерПоезда, времяОтправления);
        }

        // Сортировка массива по номерам поездов.
        Array.Sort(поезда, (x, y) => x.НомерПоезда.CompareTo(y.НомерПоезда));

        Console.Write("\nВведите номер поезда для вывода информации: ");
        int введенныйНомер = int.Parse(Console.ReadLine());

        // Поиск поезда и вывод информации.
        Train найденныйПоезд = Array.Find(поезда, поезд => поезд.НомерПоезда == введенныйНомер);

        if (найденныйПоезд.НомерПоезда != 0)
            Console.WriteLine($"\nИнформация о поезде {введенныйНомер}:\nНазвание: {найденныйПоезд.Название}, Время отправления: {найденныйПоезд.ВремяОтправления}");
        else
            Console.WriteLine("Поезд с таким номером не найден.");

        // Задание 3
        // Создание экземпляра класса и структуры с полем change.
        MyClass класс = new MyClass();
        MyStruct структура = new MyStruct();

        Console.WriteLine("\nЗначения полей до вызова методов:");
        Console.WriteLine($"Класс: {класс.change}, Структура: {структура.change}");

        // Вызов методов для изменения значений полей.
        ClassTaker(класс);
        StruktTaker(структура);

        Console.WriteLine("\nЗначения полей после вызова методов:");
        Console.WriteLine($"Класс: {класс.change}, Структура: {структура.change}");
    }

    // Метод для изменения значения поля change у экземпляра класса MyClass.
    static void ClassTaker(MyClass myClass)
    {
        myClass.change = "изменено";
    }

    // Метод для изменения значения поля change у экземпляра структуры MyStruct.
    static void StruktTaker(MyStruct myStruct)
    {
        myStruct.change = "изменено";
    }
}

// Класс содержащий поле change.
public class MyClass
{
    public string change = "не изменено";
}

// Структура содержащая поле change.
public struct MyStruct
{
    public string change;
}
﻿using System;
using System.Threading;

class Program
{
    static void Main()
    {
        RecursiveMethod(7);
        Console.ReadLine(); // Пауза для отображения результатов в консоли
    }

    static void RecursiveMethod(int count)
    {
        if (count > 0)
        {
            Thread thread = new Thread(() =>
            {
                Console.WriteLine($"Выполнение вызова метода с параметром {count} в потоке {Thread.CurrentThread.ManagedThreadId}");
                RecursiveMethod(count - 1);
            });
            thread.Start();
        }
    }
}
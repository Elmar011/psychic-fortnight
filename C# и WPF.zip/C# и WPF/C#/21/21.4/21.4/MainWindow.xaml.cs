﻿using System;
using System.Windows;

namespace CalculatorApp
{
    public interface ICalculatorView
    {
        void UpdateResult(string result);
    }
}
namespace CalculatorApp
{
    public partial class MainWindow : Window, ICalculatorView
    {
        private CalculatorPresenter _presenter;

        public MainWindow()
        {
            InitializeComponent();
            _presenter = new CalculatorPresenter(this);
        }

        public void UpdateResult(string result)
        {
            ResultTextBox.Text = result;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            _presenter.PerformAddition();
        }

        private void SubtractButton_Click(object sender, RoutedEventArgs e)
        {
            _presenter.PerformSubtraction();
        }

        private void MultiplyButton_Click(object sender, RoutedEventArgs e)
        {
            _presenter.PerformMultiplication();
        }

        private void DivideButton_Click(object sender, RoutedEventArgs e)
        {
            _presenter.PerformDivision();
        }
    }
}

namespace CalculatorApp
{
    public class CalculatorPresenter
    {
        private ICalculatorView _view;

        public CalculatorPresenter(ICalculatorView view)
        {
            _view = view;
        }

        public void PerformAddition()
        {
            // Perform addition logic here
            double result = 10 + 20;
            _view.UpdateResult(result.ToString());
        }

        public void PerformSubtraction()
        {
            // Perform subtraction logic here
            double result = 30 - 10;
            _view.UpdateResult(result.ToString());
        }

        public void PerformMultiplication()
        {
            // Perform multiplication logic here
            double result = 5 * 4;
            _view.UpdateResult(result.ToString());
        }

        public void PerformDivision()
        {
            // Perform division logic here
            double result = 20 / 4;
            _view.UpdateResult(result.ToString());
        }
    }
}
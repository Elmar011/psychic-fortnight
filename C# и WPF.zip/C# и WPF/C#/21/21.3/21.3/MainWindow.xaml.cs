﻿using System;
using System.Windows;
using System.Windows.Media;

namespace StopwatchApp
{
    public class StopwatchModel
    {
        private TimeSpan _elapsedTime;
        private bool _isRunning;

        public TimeSpan ElapsedTime
        {
            get => _elapsedTime;
        }

        public bool IsRunning
        {
            get => _isRunning;
        }

        public void Start()
        {
            _isRunning = true;
        }

        public void Stop()
        {
            _isRunning = false;
        }

        public void Reset()
        {
            _elapsedTime = TimeSpan.Zero;
        }

        public void Update(TimeSpan elapsed)
        {
            if (_isRunning)
            {
                _elapsedTime = _elapsedTime.Add(elapsed);
            }
        }
    }
}

namespace StopwatchApp
{
    public interface IStopwatchView
    {
        TimeSpan ElapsedTime { set; }
        event EventHandler StartClicked;
        event EventHandler StopClicked;
        event EventHandler ResetClicked;
    }
}

namespace StopwatchApp
{
    public class StopwatchPresenter
    {
        private readonly StopwatchModel _model;
        private readonly IStopwatchView _view;

        public StopwatchPresenter(StopwatchModel model, IStopwatchView view)
        {
            _model = model;
            _view = view;

            _view.StartClicked += OnStartClicked;
            _view.StopClicked += OnStopClicked;
            _view.ResetClicked += OnResetClicked;
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            _model.Start();
        }

        private void OnStopClicked(object sender, EventArgs e)
        {
            _model.Stop();
        }

        private void OnResetClicked(object sender, EventArgs e)
        {
            _model.Reset();
        }

        public void Update(TimeSpan elapsed)
        {
            _model.Update(elapsed);
            _view.ElapsedTime = _model.ElapsedTime;
        }
    }
}
namespace StopwatchApp
{
    public partial class MainWindow : Window, IStopwatchView
    {
        private readonly StopwatchPresenter _presenter;

        public TimeSpan ElapsedTime
        {
            set => TimeLabel.Content = value.ToString(@"hh\:mm\:ss");
        }

        public event EventHandler StartClicked;
        public event EventHandler StopClicked;
        public event EventHandler ResetClicked;

        public MainWindow()
        {
            InitializeComponent();

            var model = new StopwatchModel();
            _presenter = new StopwatchPresenter(model, this);
            CompositionTarget.Rendering += OnRender;
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            StartClicked?.Invoke(this, EventArgs.Empty);
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            StopClicked?.Invoke(this, EventArgs.Empty);
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResetClicked?.Invoke(this, EventArgs.Empty);
        }

        private void OnRender(object sender, EventArgs e)
        {
            _presenter.Update(TimeSpan.FromSeconds(1));
        }
    }
}
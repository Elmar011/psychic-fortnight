﻿using System; // импортируем пространство имён System, предоставляя доступ к его классам и методам.

namespace ConsoleApplication // cоздаём новое пространство имён с именем ConsoleApplication.
{
    class Address
    { //  определяем класс Address, содержащий свойства и методы для работы с адресом.
        private string index; // объявляет приватное поле index типа string.
        private string country; // объявляет приватное поле country типа string.
        private string city; // объявляет приватное поле city типа string.
        private string street; // объявляет приватное поле street типа string.
        private string house; // объявляет приватное поле house типа string.
        private string apartment; // объявляет приватное поле apartment типа string.

        public string Index //  определяем публичное свойство Index типа string, которое возвращает значение индекса.
        {
            get { return index; }
            //  устанавливает геттер для свойства Index, который возвращает значение индекса.
            set { index = value; } // устанавливает сеттер для свойства Index, который присваивает значение переменной index.
        }

        public string Country // определяет публичное свойство Country типа string, которое возвращает значение страны.
        {
            get { return country; }// устанавливает геттер для свойства Country, который возвращает значение страны.
            set { country = value; } // устанавливает сеттер для свойства Country, который присваивает значение переменной country.
        }

        public string City //определяет публичное свойство City типа string, которое возвращает значение города.
        {
            get { return city; } // устанавливает геттер для свойства City, который возвращает значение города.
            set { city = value; } // устанавливает сеттер для свойства City, который присваивает значение переменной city.
        }

        public string Street // определяет публичное свойство Street типа string, которое возвращает значение улицы.
        {
            get { return street; } // устанавливает геттер для свойства Street, который возвращает значение улицы.
            set { street = value; } // устанавливает сеттер для свойства Street, который присваивает значение переменной street.
        }

        public string House // определяет публичное свойство House типа string, которое возвращает значение дома.
        {
            get { return house; } //  устанавливает геттер для свойства House, который возвращает значение дома.
            set { house = value; } // устанавливает сеттер для свойства House, который присваивает значение переменной house.
        }

        public string Apartment // определяет публичное свойство Apartment типа string, которое возвращает значение квартиры.
        {
            get { return apartment; } //устанавливает геттер для свойства Apartment, который возвращает значение квартиры.
            set { apartment = value; } // устанавливает сеттер для свойства Apartment, который присваивает значение переменной apartmen
        }
    }

    class Program // определяет класс Program, содержащий метод Main().
    {
        static void Main(string[] args) // определяет статический метод Main(), который является точкой входа программы.
        {
            Address myAddress = new Address(); //создаёт экземпляр класса Address.
            myAddress.Index = "777"; //присваивает значение индексу.
            myAddress.Country = "RUS"; //присваивает значение стране.
            myAddress.City = "MSK"; //присваивает значение городу.
            myAddress.Street = "New.Arbat"; //присваивает значение улице.
            myAddress.House = "26";//присваивает значение дому.
            myAddress.Apartment = "23"; //присваивает значение квартире.


            Console.WriteLine("Index: " + myAddress.Index); //выводит значение индекса.
            Console.WriteLine("Country: " + myAddress.Country); // выводит значение страны.
            Console.WriteLine("City: " + myAddress.City);//выводит значение города.
            Console.WriteLine("Street: " + myAddress.Street);//выводит значение улицы.
            Console.WriteLine("House: " + myAddress.House);//выводит значение дома.
            Console.WriteLine("Apartment: " + myAddress.Apartment);

            Console.ReadKey();
        }
    }
}

﻿using System;

// Класс Point представляет точку с координатами X, Y и названием
class Point
{
    public int X { get; }
    public int Y { get; }
    public string Name { get; }

    public Point(int x, int y, string name)
    {
        X = x;
        Y = y;
        Name = name;
    }
}

// Класс Figure представляет многоугольник
class Figure
{
    private Point[] points; // Массив точек

    public Figure(params Point[] points)
    {
        if (points.Length < 3 || points.Length > 5)
        {
            throw new ArgumentException("Многоугольник должен иметь от 3 до 5 точек.");
        }

        this.points = points;
    }

    // Метод для расчета длины стороны между двумя точками
    private double LengthSide(Point A, Point B)
    {
        int deltaX = A.X - B.X;
        int deltaY = A.Y - B.Y;
        return Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
    }

    // Метод для расчета периметра многоугольника
    public double PerimeterCalculator()
    {
        double perimeter = 0;
        for (int i = 0; i < points.Length; i++)
        {
            int nextIndex = (i + 1) % points.Length; // Индекс следующей точки (зацикливание к первой точке)
            perimeter += LengthSide(points[i], points[nextIndex]);
        }
        return perimeter;
    }
}

class Program
{
    static void Main()
    {
        try
        {
            // Создаем точки для многоугольника
            Point A = new Point(0, 0, "A");
            Point B = new Point(0, 4, "B");
            Point C = new Point(3, 0, "C");

            // Создаем многоугольник и передаем точки в конструктор
            Figure triangle = new Figure(A, B, C);

            // Выводим на экран название и периметр многоугольника
            Console.WriteLine("Многоугольник: ABC");
            Console.WriteLine($"Периметр: {triangle.PerimeterCalculator()}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.ReadKey();
    }
}

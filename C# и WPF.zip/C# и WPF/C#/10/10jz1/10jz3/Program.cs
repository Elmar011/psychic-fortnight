﻿using System;

// Класс Title представляет название книги
class Title
{
    private string title;

    public Title(string title)
    {
        this.title = title;
    }

    public void Show()
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"Название книги: {title}");
        Console.ResetColor();
    }
}

// Класс Author представляет имя автора книги
class Author
{
    private string authorName;

    public Author(string authorName)
    {
        this.authorName = authorName;
    }

    public void Show()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"Автор книги: {authorName}");
        Console.ResetColor();
    }
}

// Класс Content представляет содержание книги
class Content
{
    private string content;

    public Content(string content)
    {
        this.content = content;
    }

    public void Show()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine($"Содержание книги:\n{content}");
        Console.ResetColor();
    }
}

// Класс Book объединяет название, автора и содержание книги
class Book
{
    private Title title;
    private Author author;
    private Content content;

    public Book(string title, string author, string content)
    {
        this.title = new Title(title);
        this.author = new Author(author);
        this.content = new Content(content);
    }

    public void Show()
    {
        title.Show();
        author.Show();
        content.Show();
    }
}

class Program
{
    static void Main()
    {
        // Создаем книгу и выводим её на экран
        Book book = new Book("Гении и Аутсайдеры", "Мальклм Гладуэл", "Почему одним всё а  другим ничего.");
        book.Show();

        Console.ReadKey();
    }
}

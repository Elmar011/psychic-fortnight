﻿using System;

class Rectangle // представляет собой прямоугольник, у которого есть две стороны.
{
    private double side1;
    private double side2;

    public Rectangle(double side1, double side2)
    {
        this.side1 = side1;
        this.side2 = side2;
    }

    public double AreaCalculator() // вычисляет площадь прямоугольника как произведение длин двух сторон.
    {
        return side1 * side2;
    }

    public double PerimeterCalculator() // вычисляет периметр прямоугольника как сумму длин всех сторон.
    {
        return 2 * (side1 + side2);
    }

    public double Area // предоставляет доступ к вычисленной площади прямоугольника.
    {
        get { return AreaCalculator(); }
    }

    public double Perimeter // предоставляет доступ к вычисленному периметру прямоугольника.
    {
        get { return PerimeterCalculator(); }
    }
}

class Program
{
    static void Main() //  происходит взаимодействие с пользователем для ввода значений длин сторон прямоугольника.
    {
        Console.WriteLine("Введите длину первой стороны прямоугольника:");
        double side1 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Введите длину второй стороны прямоугольника:");
        double side2 = Convert.ToDouble(Console.ReadLine());

        Rectangle rectangle = new Rectangle(side1, side2); // Создается объект класса Rectangle с заданными значениями сторон.

        Console.WriteLine($"Площадь прямоугольника: {rectangle.Area}");
        Console.WriteLine($"Периметр прямоугольника: {rectangle.Perimeter}");

        Console.ReadKey(); // Выводится на экран площадь и периметр прямоугольника.
    }
}

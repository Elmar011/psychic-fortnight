﻿// See https://learn.microsoft.com/ru-ru/dotnet/csharp/language-reference/keywords/using-directive#global-modifier for more information
Console.WriteLine("Hello, World!");

-- Создание базы данных
DROP DATABASE IF EXISTS MyFunkDB_FirstName_LastName; -- Удаляет базу данных, если она уже существует
CREATE DATABASE MyFunkDB_FirstName_LastName; -- Создает новую базу данных

-- Использование базы данных
USE MyFunkDB_FirstName_LastName; -- Выбирает созданную базу данных для работы

-- Создание таблицы сотрудников
CREATE TABLE Employees ( -- Создает таблицу "Employees" с указанными полями
    ID INT PRIMARY KEY, -- Поле ID типа INT, которое является первичным ключом
    Name VARCHAR(50), -- Поле Name типа VARCHAR с максимальной длиной 50 символов
    Phone VARCHAR(15) -- Поле Phone типа VARCHAR с максимальной длиной 15 символов
);

-- Вставка данных в таблицу сотрудников
INSERT INTO Employees (ID, Name, Phone) VALUES -- Вставляет данные в таблицу Employees
(1, 'John Doe', '123-456-7890'), -- Значения для первого сотрудника
(2, 'Jane Smith', '345-678-9012'), -- Значения для второго сотрудника
(3, 'Alice Johnson', '567-890-1234'); -- Значения для третьего сотрудника

-- Создание таблицы с ведомостями о зарплате и должностях
CREATE TABLE Salaries ( -- Создает таблицу "Salaries" с указанными полями
    EmployeeID INT, -- Поле EmployeeID типа INT
    Position VARCHAR(20), -- Поле Position типа VARCHAR с максимальной длиной 20 символов
    Salary DECIMAL(10,2) -- Поле Salary типа DECIMAL с общим числом цифр 10 и 2 дробными
);

-- Вставка данных в таблицу с ведомостями о зарплате и должностях
INSERT INTO Salaries (EmployeeID, Position, Salary) VALUES -- Вставляет данные в таблицу Salaries
(1, 'Главный директор', 10000.00), -- Значения для первого сотрудника
(2, 'Менеджер', 5000.00), -- Значения для второго сотрудника
(3, 'Рабочий', 3000.00); -- Значения для третьего сотрудника

-- Создание таблицы с информацией о семейном положении, дате рождения и месте жительства
CREATE TABLE PersonalInfo ( -- Создает таблицу "PersonalInfo" с указанными полями
    EmployeeID INT, -- Поле EmployeeID типа INT
    MaritalStatus VARCHAR(10), -- Поле MaritalStatus типа VARCHAR с максимальной длиной 10 символов
    BirthDate DATE, -- Поле BirthDate типа DATE
    Address VARCHAR(100) -- Поле Address типа VARCHAR с максимальной длиной 100 символов
);

-- Вставка данных в таблицу с информацией о семейном положении, дате рождения и месте жительства
INSERT INTO PersonalInfo (EmployeeID, MaritalStatus, BirthDate, Address) VALUES -- Вставляет данные в таблицу PersonalInfo
(1, 'Женат', '1985-05-15', '123 Main St, City, State, Zip'), -- Значение для первого сотрудника
(2, 'Не замужем', '1990-12-30', '456 Elm St, City, State, Zip'), -- Значение для второго сотрудника
(3, 'Разведен', '1978-07-20', '789 Oak St, City, State, Zip'); -- Значение для третьего сотрудника

-- Создание функции для получения контактных данных сотрудников
DELIMITER // -- Устанавливает разделитель для создания функции
CREATE PROCEDURE GetContactInfo(IN EmployeeID INT) -- Создает процедуру GetContactInfo с параметром EmployeeID 
BEGIN
    SELECT CONCAT('Телефон: ', Phone, ', Адрес: ', Address) AS ContactInfo -- Выбирает контактные данные сотрудников
    FROM Employees
    INNER JOIN PersonalInfo ON Employees.ID = PersonalInfo.EmployeeID
    WHERE Employees.ID = EmployeeID; -- Ограничивает результат по указанному EmployeeID
END // -- Конец определения функции
DELIMITER ; -- Восстанавливает стандартный разделитель

-- Пример вызова функции для получения контактных данных сотрудника с ID = 1
Call GetContactInfo(1);

-- Создание процедуры для получения информации о дате рождения не женатых сотрудников и их номеров телефонов
DELIMITER // -- Устанавливает разделитель для создания процедуры
CREATE PROCEDURE GetUnmarriedEmployeesInfo() -- Создает процедуру GetUnmarriedEmployeesInfo
BEGIN
    SELECT Name, BirthDate, Phone -- Выбирает имя, дату рождения и номер телефона сотрудника
    FROM Employees
    INNER JOIN PersonalInfo ON Employees.ID = PersonalInfo.EmployeeID
    WHERE PersonalInfo.MaritalStatus = 'Не замужем'; -- Ограничивает результат для не женатых сотрудников
END // -- Конец определения процедуры
DELIMITER ; -- Восстанавливает стандартный разделитель

-- Вызов процедуры для получения информации о дате рождения и номерах телефонов не женатых сотрудников
CALL GetUnmarriedEmployeesInfo();

-- Создание процедуры для получения информации о дате рождения и номерах телефонов сотрудников с должностью менеджер
DELIMITER // -- Устанавливает разделитель для создания процедуры
CREATE PROCEDURE GetManagersInfo() -- Создает процедуру GetManagersInfo
BEGIN
    SELECT Employees.Name, PersonalInfo.BirthDate, Employees.Phone -- Выбирает имя, дату рождения и номер телефона сотрудника
    FROM Employees
    INNER JOIN Salaries ON Employees.ID = Salaries.EmployeeID
    INNER JOIN PersonalInfo ON Employees.ID = PersonalInfo.EmployeeID
    WHERE Salaries.Position = 'Менеджер'; -- Ограничивает результат для сотрудников с должностью "Менеджер"
END // -- Конец определения процедуры
DELIMITER ; -- Восстанавливает стандартный разделитель

-- Вызов процедуры для получения информации о дате рождения и номерах телефонов сотрудников с должностью менеджер
CALL GetManagersInfo();
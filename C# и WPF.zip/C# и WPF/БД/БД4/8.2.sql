-- Удаляем базу данных, если она уже существует, чтобы избежать конфликта
Drop DataBase if exists MyFunkDB_FirstName_LastName;
-- Создаем новую базу данных с указанным названием
CREATE DATABASE MyFunkDB_FirstName_LastName;
-- Выбираем созданную базу данных для работы
USE MyFunkDB_FirstName_LastName;

-- Создаем таблицу Employees с необходимыми полями
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_name VARCHAR(100),
    phone_number VARCHAR(20)
);

-- Создаем таблицу Payroll с указанием внешнего ключа к полю employee_id из таблицы Employees
CREATE TABLE Payroll (
    employee_id INT PRIMARY KEY,
    position VARCHAR(50),
    salary DECIMAL(10,2),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Создаем таблицу PersonalInformation с указанием внешнего ключа к полю employee_id из таблицы Employees
CREATE TABLE PersonalInformation (
    employee_id INT PRIMARY KEY,
    marital_status VARCHAR(20),
    date_of_birth DATE,
    address VARCHAR(100),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Вставляем данные в таблицу Employees
INSERT INTO Employees (employee_name, phone_number)
VALUES ('John Smith', '123-456-7890'),
       ('Jane Doe', '987-654-3210'),
       ('Mike Johnson', '567-890-1234');

-- Вставляем данные в таблицу Payroll
INSERT INTO Payroll (employee_id, position, salary)
VALUES (1, 'Manager', 60000.00),
       (2, 'Assistant Manager', 45000.00),
       (3, 'Sales Associate', 30000.00);

-- Вставляем данные в таблицу PersonalInformation
INSERT INTO PersonalInformation (employee_id, marital_status, date_of_birth, address)
VALUES (1, 'Married', '1980-05-15', '123 Main St, Anytown, USA'),
       (2, 'Single', '1990-10-20', '456 Elm St, Othertown, USA'),
       (3, 'Divorced', '1975-02-25', '789 Oak St, Thistown, USA');

-- Устанавливаем разделитель для создания процедуры
DELIMITER $$
-- Создаем процедуру InsertEmployeeData, которая добавляет данные о новом сотруднике
CREATE PROCEDURE InsertEmployeeData() BEGIN 
    -- Создаем флаг для отката транзакции
    DECLARE rollback_flag BOOLEAN DEFAULT 0;

    -- Начинаем транзакцию
    START TRANSACTION;

    -- Вставляем данные о новом сотруднике в таблицу Employees
    INSERT INTO Employees (employee_name, phone_number)
    VALUES ('John Smith', '123-456-7890');

    -- Проверяем флаг для отката транзакции
    IF rollback_flag THEN
        ROLLBACK;
    END IF;

    -- Вставляем данные о должности нового сотрудника в таблицу Payroll
    INSERT INTO Payroll (employee_id, position, salary)
    VALUES (LAST_INSERT_ID(), 'Manager', 60000.00);

    -- Проверяем флаг для отката транзакции
    IF rollback_flag THEN
        ROLLBACK;
    END IF;

    -- Вставляем персональные данные нового сотрудника в таблицу PersonalInformation
    INSERT INTO PersonalInformation (employee_id, marital_status, date_of_birth, address)
    VALUES (LAST_INSERT_ID(), 'Married', '1980-05-15', '123 Main St, Anytown, USA');

    -- Проверяем флаг для отката транзакции и завершаем транзакцию
    IF rollback_flag THEN
        ROLLBACK;
    ELSE
        COMMIT;
    END IF;
END$$ 
-- Возвращаем стандартный разделитель
DELIMITER ;
-- Вызываем созданную процедуру для добавления данных о новом сотруднике
CALL InsertEmployeeData();

-- Создаем триггер DeleteRecordsBeforeEmployees, который удаляет связанные записи из таблиц Payroll и PersonalInformation перед удалением сотрудника из таблицы Employees
DROP TRIGGER IF EXISTS DeleteRecordsBeforeEmployees;

DELIMITER $$
CREATE TRIGGER DeleteRecordsBeforeEmployees
BEFORE DELETE ON Employees
FOR EACH ROW
BEGIN
    DELETE FROM Payroll WHERE employee_id = OLD.employee_id;
    DELETE FROM PersonalInformation WHERE employee_id = OLD.employee_id;
END$$

DELIMITER ;
-- Откат базы данных, если данные не были добавлены корректно, иначе можно оставить базу данных в текущем состоянии
-- Анализ результата выполнения позволит определить необходимость отката базы данных
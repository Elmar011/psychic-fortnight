DROP DATABASE IF EXISTS SHOPDB;

CREATE DATABASE ShopDB;

USE SHOPDB;
-- Удаляем таблицу, если она уже существует

-- Создаем таблицу Customers
CREATE TABLE Customers (
    CustomerID INT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(50),
    Phone VARCHAR(15)
);

-- Заполняем таблицу данными
INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Phone) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '123-456-7890'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '456-789-1230'),
(3, 'Michael', 'Johnson', 'michael.johnson@example.com', '789-123-4560');

-- Добавляем индекс на столбец CustomerID
CREATE INDEX idx_CustomerID ON Customers(CustomerID);

-- Добавляем индекс на столбец LastName
CREATE INDEX idx_LastName ON Customers(LastName);
-- Выборка данных с использованием индекса
EXPLAIN SELECT * FROM Customers WHERE CustomerID = 1;

-- Удаляем базу данных carsshop, если она существует
DROP DATABASE IF EXISTS carsshop;

-- Создаем базу данных carsshop
CREATE DATABASE carsshop;

-- Используем базу данных carsshop
USE carsshop;

-- Создаем таблицу clients с тремя колонками: id, name, age
CREATE TABLE clients (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT
);

-- Создаем таблицу cars с четырьмя колонками: id, brand, model, price
CREATE TABLE cars (
    id INT PRIMARY KEY,
    brand VARCHAR(50),
    model VARCHAR(50),
    price INT
);

-- Создаем таблицу purchases с четырьмя колонками: id, client_id, car_id, purchase_date
CREATE TABLE purchases (
    id INT PRIMARY KEY,
    client_id INT,
    car_id INT,
    purchase_date DATE
);

-- Вставляем данные в таблицу clients
INSERT INTO clients (id, name, age) VALUES
(1, 'Alice', 25),
(2, 'Bob', 30),
(3, 'Charlie', 35);

-- Вставляем данные в таблицу cars
INSERT INTO cars (id, brand, model, price) VALUES
(1, 'Toyota', 'Corolla', 20000),
(2, 'Honda', 'Civic', 22000),
(3, 'Ford', 'Fiesta', 18000);

-- Вставляем данные в таблицу purchases
INSERT INTO purchases (id, client_id, car_id, purchase_date) VALUES
(1, 1, 1, '2021-01-15'),
(2, 1, 2, '2021-02-20'),
(3, 2, 3, '2021-03-25'),
(4, 3, 1, '2021-04-30');

-- Устанавливаем новый разделитель запросов
DELIMITER //

-- Создаем функцию get_min_client_age
CREATE FUNCTION get_min_client_age() RETURNS INT DETERMINISTIC
BEGIN
    DECLARE min_age INT;

    -- Выполняем запрос, чтобы найти минимальный возраст клиента
    SELECT MIN(age) INTO min_age FROM clients;

    -- Возвращаем минимальный возраст в качестве результата функции
    RETURN min_age;
END//

-- Восстанавливаем разделитель запросов по умолчанию
DELIMITER //

-- Вызываем функцию get_min_client_age и выводим результат
SELECT get_min_client_age();
-- Создание базы данных
CREATE DATABASE IF NOT EXISTS hr_system;
USE hr_system;

-- Создание таблицы Отделы
CREATE TABLE Departments 
(
    department_id INT PRIMARY KEY,
    department_name VARCHAR(50)
);

-- Создание таблицы Сотрудники
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    date_of_birth DATE,
    department_id INT,
    position VARCHAR(50),
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

-- Создание таблицы Зарплаты
CREATE TABLE Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    salary_amount DECIMAL(10, 2),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Вставка данных в таблицу Отделы
INSERT INTO Departments (department_id, department_name) VALUES
(1, 'HR'),
(2, 'IT');

-- Вставка данных в таблицу Сотрудники
INSERT INTO Employees (employee_id, first_name, last_name, date_of_birth, department_id, position) VALUES
(4, 'Dima', 'Pospelov', '1990-05-15', 1, 'Manager'),
(5, 'Akakiy', 'Akakushkin', '1988-12-10', 2, 'Developer'),
(6, 'Bob', 'Brown', '1995-02-20', 1, 'HR');

-- Вставка данных в таблицу Зарплаты
INSERT INTO Salaries (salary_id, employee_id, salary_amount) VALUES
(1, 1, 50000),
(2, 2, 60000),
(3, 3, 45000);

SELECT * FROM hr_system;
SELECT * FROM Employees;
SELECT * FROM Salaries;
SELECT * FROM Departments
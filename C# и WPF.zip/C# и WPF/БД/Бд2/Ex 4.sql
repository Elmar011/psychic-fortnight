USE MyDB_FirstName_LastName;

SELECT * FROM statement WHERE salary > 10000;

SELECT id, name, salary, post;

insert into statement(name, salary, post) values('Dimaa', 10000, 'Manager');
insert into statement(name, salary, post) values('Marat', 11000, 'Proger');
insert into statement(name, salary, post) values('Mahrajab', 9000, 'Tester');
insert into statement(name, salary, post) values('Worker', 12000, 'Modeler');
USE Army;

CREATE TABLE Employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    grade VARCHAR(50),
    office VARCHAR(50),
    platoon INT
);

CREATE TABLE Weapons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR(50),
    issued_by VARCHAR(50),
    issued_to INT,
    FOREIGN KEY (issued_to) REFERENCES Employees(id)
);

INSERT INTO Employees (name, gradeemployees, office, platoon) VALUES 
('Петров В.А.', 'оф.205', '222', 1),
('Лодарев П.С.', 'оф.221', '232', 1),
('Леонтьев К.В.', 'оф.201', '212', 1),
('Духов Р.М.', NULL, '200', 1);

INSERT INTO Weapons (type, issued_by, issued_to) VALUES
('АК-47', 'Буров О.С., майор', 1),
('П.М.', 'Рыбаков Н.Г., майор', 1),
('АК-74', 'Деребанов В.Я., подполковник', 2),
('П.М.', 'Рыбаков Н.Г., майор', 2),
('АК-47', 'Буров О.С., майор', 3);

-- Задаем текущую базу данных для работы
USE Warehouse;

-- Создаем таблицу "employees" для хранения информации о сотрудниках
CREATE TABLE employees (
    id_employee INT PRIMARY KEY,
    full_name VARCHAR(50),
    birth_date DATE,
    gender VARCHAR(10),
    address VARCHAR(100),
    phone_number VARCHAR(15),
    position_id INT,
    salary DECIMAL(10, 2)
);

-- Создаем таблицу "departments" для хранения информации о департаментах
CREATE TABLE departments (
    id_department INT PRIMARY KEY,
    department_name VARCHAR(50)
);

-- Создаем таблицу "positions" для хранения информации о должностях
CREATE TABLE positions (
    id_position INT PRIMARY KEY,
    position_name VARCHAR(50)
);

-- Создаем таблицу "employee_department" для связи сотрудников с департаментами
CREATE TABLE employee_department (
    id_employee_department INT PRIMARY KEY,
    employee_id INT,
    department_id INT,
    FOREIGN KEY (employee_id) REFERENCES employees(id_employee),
    FOREIGN KEY (department_id) REFERENCES departments(id_department)
);

-- Создаем таблицу "employee_position" для связи сотрудников с должностями
CREATE TABLE employee_position (
    id_employee_position INT PRIMARY KEY,
    employee_id INT,
    position_id INT,
    FOREIGN KEY (employee_id) REFERENCES employees(id_employee),
    FOREIGN KEY (position_id) REFERENCES positions(id_position)
);

-- Создаем таблицу "suppliers" для хранения информации о поставщиках
CREATE TABLE suppliers (
    id_supplier INT PRIMARY KEY,
    supplier_name VARCHAR(50),
    address VARCHAR(100),
    phone_number VARCHAR(15)
);

-- Создаем таблицу "products" для хранения информации о продуктах
CREATE TABLE products (
    id_product INT PRIMARY KEY,
    product_name VARCHAR(50),
    price DECIMAL(10, 2),
    quantity INT,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id_supplier)
);

-- Создаем таблицу "customers" для хранения информации о клиентах
CREATE TABLE customers (
    id_customer INT PRIMARY KEY,
    company_name VARCHAR(50),
    address VARCHAR(100),
    phone_number VARCHAR(15)
);

-- Создаем таблицу "orders" для хранения информации о заказах
CREATE TABLE orders (
    id_order INT PRIMARY KEY, -- создаем столбец для уникального идентификатора заказа
    product_id INT, -- создаем столбец для идентификатора продукта в заказе
    customer_id INT, -- создаем столбец для идентификатора заказчика
    quantity INT, -- создаем столбец для количества продукта в заказе
    order_date DATE, -- создаем столбец для даты заказа
    FOREIGN KEY (product_id) REFERENCES products(id_product), -- создаем внешний ключ для связи с таблицей "products" по идентификатору продукта
    FOREIGN KEY (customer_id) REFERENCES customers(id_customer) -- создаем внешний ключ для связи с таблицей "customers" по идентификатору заказчика
);

-- Создаем таблицу "employee_orders" для связи сотрудников с заказами
CREATE TABLE employee_orders (
    id_employee_order INT PRIMARY KEY, -- создаем столбец для уникального идентификатора связи сотрудника и заказа
    employee_id INT, -- создаем столбец для идентификатора сотрудника
    order_id INT, -- создаем столбец для идентификатора заказа
    FOREIGN KEY (employee_id) REFERENCES employees(id_employee), -- создаем внешний ключ для связи с таблицей "employees" по идентификатору сотрудника
    FOREIGN KEY (order_id) REFERENCES orders(id_order) -- создаем внешний ключ для связи с таблицей "orders" по идентификатору заказа
);


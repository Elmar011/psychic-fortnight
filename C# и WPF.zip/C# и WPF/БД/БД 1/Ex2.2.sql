-- Создание базы данных с именем MyDB_FirstName_LastNameeee
CREATE DATABASE MyDB_FirstName_LastNameeee;

-- Создание таблицы Employees с полями id, name и phone_number
CREATE TABLE Employees (
id INT PRIMARY KEY,
name VARCHAR(50),
phone_number VARCHAR(20)
);

-- Создание таблицы Salary с полями id, employee_id, salary и position
CREATE TABLE Salary (
id INT PRIMARY KEY,
employee_id INT,
salary DECIMAL(10, 2),
position VARCHAR(50)
);

-- Создание таблицы PersonalInfo с полями id, employee_id, marital_status, date_of_birth и address
CREATE TABLE PersonalInfo (
id INT PRIMARY KEY,
employee_id INT,
marital_status VARCHAR(20),
date_of_birth DATE,
address VARCHAR(100)
);

-- Вставка данных в таблицу Employees
INSERT INTO Employees (id, name, phone_number) VALUES (1, 'John Doe', '555-1234');
-- Вставка данных в таблицу Salary
INSERT INTO Salary (id, employee_id, salary, position) VALUES (1, 1, 15000.00, 'Manager');
-- Вставка данных в таблицу PersonalInfo
INSERT INTO PersonalInfo (id, employee_id, marital_status, date_of_birth, address) VALUES (1, 1, 'Ruslan', '2005-10-06', 'Vorkuta');

-- Выбор поля employee_id из таблицы Salary, где значение поля salary больше 10000
SELECT employee_id
FROM Salary
WHERE salary > 10000;
-- Создание базы данных с названием MyDB_FirstName_LastName
CREATE DATABASE MyDB_FirstName_LastName;

-- Использование созданной базы данных
USE MyDB_FirstName_LastName;

-- Создание таблицы Employees с полями employee_id, name и phone_number
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(50),
    phone_number VARCHAR(15)
);

-- Создание таблицы Salaries с полями salary_id, employee_id, salary и position, добавление внешнего ключа employee_id
CREATE TABLE Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    salary DECIMAL(10, 2),
    position VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Создание таблицы Family с полями family_id, employee_id, marital_status, date_of_birth, residence, добавление внешнего ключа employee_id
CREATE TABLE Family (
    family_id INT PRIMARY KEY,
    employee_id INT,
    marital_status VARCHAR(20),
    date_of_birth DATE,
    residence VARCHAR(100),
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Выбор поля employee_id из таблицы Salaries, где значение поля salary больше 10000
SELECT employee_id
FROM Salaries
WHERE salary > 10000;

-- Обновление таблицы Family, установка значения marital_status равным 'Married' для записи с employee_id равным 1
UPDATE Family
SET marital_status = 'Married'
WHERE employee_id = 1;
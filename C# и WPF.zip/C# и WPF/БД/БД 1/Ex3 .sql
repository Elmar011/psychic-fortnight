-- Используем базу данных под именем MyDB_FirstName_LastName
USE MyDB_FirstName_LastName;

-- Создаем таблицу Statement с полями id, name, salary, post
CREATE TABLE Statement (
id INT AUTO_INCREMENT PRIMARY KEY, -- Поле id типа INT, с автоинкрементом и первичным ключом
name VARCHAR(50),
salary DECIMAL(10, 2),
post VARCHAR(50)
);

-- Выбираем все записи из таблицы statement, где значение поля salary больше 10000
SELECT * FROM statement WHERE salary > 10000;

-- Выводим только поля id, name, salary, post из таблицы statement
SELECT id, name, salary, post;

-- Вставляем новую запись в таблицу statement с указанными значениями
insert into statement(name, salary, post) values('Ali', 10500, 'Tester');

-- Вставляем новую запись в таблицу statement с указанными значениями
insert into statement(name, salary, post) values('Sofia', 9500, 'Modeler');

-- Вставляем новую запись в таблицу statement с указанными значениями
insert into statement(name, salary, post) values('Mikhail', 11500, 'Manager');

-- Вставляем новую запись в таблицу statement с указанными значениями
insert into statement(name, salary, post) values('Katya', 10000, 'Proger');
CREATE DATABASE cars_database; -- Создание базы данных с именем cars_database

USE cars_database; -- Выбор созданной базы данных для работы

CREATE TABLE cars ( -- Создание таблицы cars
    id INT AUTO_INCREMENT PRIMARY KEY, -- Поле id типа INT, с автоинкрементом и первичным ключом
    brand VARCHAR(50), -- Поле brand типа VARCHAR длиной до 50 символов
    model VARCHAR(50), -- Поле model типа VARCHAR длиной до 50 символов
    engine_volume FLOAT, -- Поле engine_volume типа FLOAT
    price DECIMAL(10, 2), -- Поле price типа DECIMAL с 10 цифрами и 2 десятичными цифрами
    max_speed INT -- Поле max_speed типа INT
);

INSERT INTO cars (brand, model, engine_volume, price, max_speed) -- Вставка данных в таблицу cars
VALUES
(
('Tesla', 'Model S', 3.5, 80000.00, 280), -- Данные о машине Tesla Model S
('Lamborghini', 'Huracan', 5.2, 250000.00, 320), -- Данные о машине Lamborghini Huracan
('Ford', 'Mustang', 5.0, 45000.00, 300), -- Данные о машине Ford Mustang
('Chevrolet', 'Corvette', 6.2, 60000.00, 330); -- Данные о машине Chevrolet Corvette

COMMIT; -- Завершение транзакции, сохранение изменений
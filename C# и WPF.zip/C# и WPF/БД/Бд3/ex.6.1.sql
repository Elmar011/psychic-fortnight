CREATE DATABASE ShopDB;

USE ShopDB;

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(50)
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    EmployeeName VARCHAR(50)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    EmployeeID INT,
    TotalPrice DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);

INSERT INTO Customers (CustomerID, CustomerName) VALUES
(1, "Alice"),
(2, "Bob"),
(3, "Charlie");

INSERT INTO Employees (EmployeeID, EmployeeName) VALUES
(1, "David"),
(2, "Emily"),
(3, "Frank");

INSERT INTO Orders (OrderID, CustomerID, EmployeeID, TotalPrice) VALUES
(1, 1, 1, 500.00),
(2, 2, 2, 1200.00),
(3, 3, 3, 800.00),
(4, 2, 3, 1500.00);

SELECT c.CustomerName, e.EmployeeName
FROM Customers c
JOIN Orders o ON c.CustomerID = o.CustomerID
JOIN Employees e ON o.EmployeeID = e.EmployeeID
WHERE o.TotalPrice > 1000;
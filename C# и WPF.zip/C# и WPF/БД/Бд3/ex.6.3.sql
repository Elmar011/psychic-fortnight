-- Создаем базу данных с именем MyJoinsDB_FirstName_LastName (если она уже существует, то сначала удаляем её)
DROP DATABASE IF EXISTS MyJoinsDB_FirstName_LastName;
CREATE DATABASE MyJoinsDB_FirstName_LastName;
USE MyJoinsDB_FirstName_LastName;

-- Создаем таблицу Employees с полями: EmployeeID (идентификатор сотрудника), FirstName (имя), LastName (фамилия), Phone (номер телефона)
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Phone VARCHAR(20)
);

-- Создаем таблицу Salaries с полями: EmployeeID (идентификатор сотрудника), Position (должность), Salary (зарплата)
CREATE TABLE Salaries (
    EmployeeID INT PRIMARY KEY,
    Position VARCHAR(50),
    Salary DECIMAL(10, 2)
);

-- Создаем таблицу PersonalInfo с полями: EmployeeID (идентификатор сотрудника), MaritalStatus (семейное положение), BirthDate (дата рождения), Residence (место проживания)
CREATE TABLE PersonalInfo (
    EmployeeID INT PRIMARY KEY,
    MaritalStatus VARCHAR(20),
    BirthDate DATE,
    Residence VARCHAR(100)
);

-- Заполняем таблицу Employees данными о сотрудниках: EmployeeID, FirstName, LastName, Phone
INSERT INTO Employees (EmployeeID, FirstName, LastName, Phone) VALUES
(1, 'John', 'Smith', '123-456-7890'),
(2, 'Jane', 'Doe', '987-654-3210'),
(3, 'Michael', 'Johnson', '555-123-7890');

-- Заполняем таблицу Salaries данными о зарплатах сотрудников: EmployeeID, Position, Salary
INSERT INTO Salaries (EmployeeID, Position, Salary) VALUES
(1, 'Manager', 50000),
(2, 'Director', 75000),
(3, 'Worker', 30000);

-- Заполняем таблицу PersonalInfo данными о семейном положении, дате рождения и месте проживания сотрудников
INSERT INTO PersonalInfo (EmployeeID, MaritalStatus, BirthDate, Residence) VALUES
(1, 'Married', '1985-06-15', 'New York'),
(2, 'Single', '1978-12-20', 'Los Angeles'),
(3, 'Divorced', '1990-03-25', 'Chicago');

-- Создаем индекс на столбец EmployeeID в таблице Salaries для оптимизации запросов
CREATE INDEX idx_employeeid_salaries ON Salaries(EmployeeID);

-- Создаем индекс на столбец EmployeeID в таблице PersonalInfo для оптимизации запросов
CREATE INDEX idx_employeeid_personalinfo ON PersonalInfo(EmployeeID);

-- Анализируем таблицу Employees для оптимизации её структуры и запросов к ней
ANALYZE TABLE Employees;

-- Анализируем таблицу Salaries для оптимизации её структуры и запросов к ней
ANALYZE TABLE Salaries;

-- Анализируем таблицу PersonalInfo для оптимизации её структуры и запросов к ней
ANALYZE TABLE PersonalInfo;

-- Создаем представление ContactInfo, которое содержит информацию о контактных данных всех сотрудников (имя, фамилия, телефон, место проживания)
CREATE VIEW ContactInfo AS
SELECT e.FirstName, e.LastName, e.Phone, pi.Residence
FROM Employees e
JOIN PersonalInfo pi ON e.EmployeeID = pi.EmployeeID;

-- Создаем представление UnmarriedBirthdays, которое содержит информацию о дате рождения всех не женатых сотрудников и их номерах телефонов
CREATE VIEW UnmarriedBirthdays AS
SELECT e.FirstName, e.LastName, pi.BirthDate, e.Phone
FROM Employees e
JOIN PersonalInfo pi ON e.EmployeeID = pi.EmployeeID
WHERE pi.MaritalStatus = 'Single';

-- Создаем представление ManagerBirthdays, которое содержит информацию о дате рождения всех менеджеров и их номерах телефонов
CREATE VIEW ManagerBirthdays AS
SELECT e.FirstName, e.LastName, pi.BirthDate, e.Phone
FROM Employees e
JOIN PersonalInfo pi ON e.EmployeeID = pi.EmployeeID
JOIN Salaries s ON e.EmployeeID = s.EmployeeID
WHERE s.Position = 'Manager'; 

-- Создание базы данных
Drop database MyJoinsDB_FirstName_LastName;
CREATE DATABASE MyJoinsDB_FirstName_LastName;

-- Использование базы данных
USE MyJoinsDB_FirstName_LastName;

-- Создание таблицы сотрудников
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(50),
    phone_number VARCHAR(15)
);

-- Создание таблицы зарплат и должностей
CREATE TABLE Salaries (
    employee_id INT PRIMARY KEY,
    position VARCHAR(50),
    salary DECIMAL(10, 2)
);

-- Создание таблицы информации о сотрудниках
CREATE TABLE EmployeeInfo (
    employee_id INT PRIMARY KEY,
    marital_status VARCHAR(20),
    date_of_birth DATE,
    address VARCHAR(100)
);

-- Заполнение таблицы Employees данными
INSERT INTO Employees (employee_id, employee_name, phone_number) VALUES
(1, 'John Doe', '555-1234'),
(2, 'Jane Smith', '555-5678'),
(3, 'Mike Johnson', '555-9876');

-- Заполнение таблицы Salaries данными
INSERT INTO Salaries (employee_id, position, salary) VALUES
(1, 'CEO', 100000.00),
(2, 'Manager', 60000.00),
(3, 'Worker', 40000.00);

-- Заполнение таблицы EmployeeInfo данными
INSERT INTO EmployeeInfo (employee_id, marital_status, date_of_birth, address) VALUES
(1, 'Married', '1975-05-10', '123 Main St'),
(2, 'Single', '1980-12-15', '456 Elm St'),
(3, 'Divorced', '1990-02-20', '789 Oak St');

SELECT e.employee_name, ei.date_of_birth, e.phone_number 
FROM Employees e
JOIN EmployeeInfo ei ON e.employee_id = ei.employee_id
JOIN Salaries s ON e.employee_id = s.employee_id
WHERE s.position = 'Manager';

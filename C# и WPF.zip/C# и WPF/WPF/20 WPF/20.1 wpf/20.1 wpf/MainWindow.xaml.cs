﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;

namespace MultipleWindows
{
    public partial class MainWindow : Window
    {
        private List<ChildWindow> childWindows = new List<ChildWindow>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenNewWindow_Click(object sender, RoutedEventArgs e)
        {
            if (childWindows.Count < 5)
            {
                ChildWindow newWindow = new ChildWindow();
                newWindow.Closed += ChildWindow_Closed;
                childWindows.Add(newWindow);
                newWindow.Show();
            }
            else
            {
                MessageBox.Show("You can't open more than 5 windows.");
            }
        }

        private void ChildWindow_Closed(object sender, System.EventArgs e)
        {
            SaveWindowPosition((ChildWindow)sender);
            childWindows.Remove((ChildWindow)sender);
        }

        private void SaveWindowPosition(ChildWindow window)
        {
            // Save window position and size
            WindowSettings settings = new WindowSettings
            {
                Left = window.Left,
                Top = window.Top,
                Width = window.Width,
                Height = window.Height
            };

            string fileName = $"{window.GetType().Name}.dat";
            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, settings);
            }
        }
    }
}

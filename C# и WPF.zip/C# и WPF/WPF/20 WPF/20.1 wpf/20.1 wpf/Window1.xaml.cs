﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;

namespace MultipleWindows
{
    [Serializable]
    public class WindowSettings
    {
        public double Left { get; set; }
        public double Top { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
    }

    public partial class ChildWindow : Window
    {
        public ChildWindow()
        {
            InitializeComponent();
            LoadWindowPosition();
        }

        private void LoadWindowPosition()
        {
            string fileName = $"{GetType().Name}.dat";
            if (File.Exists(fileName))
            {
                using (FileStream fs = new FileStream(fileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    WindowSettings settings = (WindowSettings)bf.Deserialize(fs);

                    Left = settings.Left;
                    Top = settings.Top;
                    Width = settings.Width;
                    Height = settings.Height;
                }
            }
        }

        protected override void OnClosed(System.EventArgs e)
        {
            base.OnClosed(e);
            SaveWindowPosition();
        }

        private void SaveWindowPosition()
        {
            WindowSettings settings = new WindowSettings
            {
                Left = Left,
                Top = Top,
                Width = Width,
                Height = Height
            };

            string fileName = $"{GetType().Name}.dat";
            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, settings);
            }
        }
    }
}

﻿using System;
using System.Windows;

namespace EightBallApp
{
    public partial class MainWindow : Window
    {
        private string[] answers = {
            "Да",
            "Неа",
            "Возможно",
            "Я устал давай позже",
            "Естественно",
            "Абсолютно нет"
        };

        public MainWindow()
        {
            InitializeComponent();
        }

        private void GetAnswer_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            int index = random.Next(answers.Length);
            answerTextBlock.Text = answers[index];
            answerTextBlock.Visibility = Visibility.Visible;
        }
    }
}

﻿// Импорт пространства имен System
// Импорт пространства имен System.Windows
// Импорт пространства имен System.Windows.Controls

// Объявление и определение класса MainWindow, который наследует класс Window
using System.Windows;

namespace LoginApp
{
    // Определение части класса MainWindow
    public partial class MainWindow : Window
    {
        // Конструктор класса MainWindow
        public MainWindow()
        {
        }

        // Обработчик события нажатия на кнопку ConfirmButton
        private void ConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            // Получение значения введенного логина из TextBox
            string login = LoginTextBox.Text;
            // Получение значения введенного пароля из PasswordBox
            string password = PasswordBox.Text;

            // Проверка соответствия введенных данных логину и паролю
            if (login == "Login" && password == "Password")
            {
                // Вывод сообщения об успешной авторизации
                MessageBox.Show("Успех", "Добро пожаловать", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Вывод сообщения об ошибке авторизации
                MessageBox.Show("Потрачено", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
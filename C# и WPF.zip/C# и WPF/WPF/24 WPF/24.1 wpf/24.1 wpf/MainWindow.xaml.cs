﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (sender is Slider slider)
            {
                double newSize = slider.Value;
                resizableText.FontSize = newSize;
                contentGrid.LayoutTransform = new ScaleTransform(newSize / 14, newSize / 14);
            }
        }
    }
}

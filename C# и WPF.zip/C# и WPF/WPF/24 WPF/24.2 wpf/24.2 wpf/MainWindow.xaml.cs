﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace DatabaseConnectionApp
{
    public partial class MainWindow : Window
    {
        private string connectionString;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            string server = ServerTextBox.Text.Trim();
            string database = DatabaseTextBox.Text.Trim();
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrWhiteSpace(server) || string.IsNullOrWhiteSpace(database) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля для подключения к базе данных.");
                return;
            }

            connectionString = $"Data Source={server};Initial Catalog={database};User ID={username};Password={password}";

            string query = "SELECT * FROM YourTable"; // Замените YourTable на имя таблицы

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Отображаем результат в DataGrid
                    DataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при выполнении запроса: {ex.Message}");
            }
        }

        // Добавляем ограничения на минимальный и максимальный размер окна
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);
            const double minWidth = 400;
            const double minHeight = 300;
            const double maxWidth = 800;
            const double maxHeight = 600;

            if (sizeInfo.NewSize.Width < minWidth || sizeInfo.NewSize.Height < minHeight)
            {
                this.MinWidth = minWidth;
                this.MinHeight = minHeight;
            }
            if (sizeInfo.NewSize.Width > maxWidth || sizeInfo.NewSize.Height > maxHeight)
            {
                this.MaxWidth = maxWidth;
                this.MaxHeight = maxHeight;
            }
        }
    }
}

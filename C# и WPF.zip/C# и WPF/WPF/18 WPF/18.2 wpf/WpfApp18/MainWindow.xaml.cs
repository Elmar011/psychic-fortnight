﻿using System; // Подключение пространства имен System
using System.Windows; // Подключение пространства имен System.Windows
using System.Windows.Controls; // Подключение пространства имен System.Windows.Controls

namespace CalculatorWPF // Объявление пространства имен CalculatorWPF
{
    public class Calculator // Объявление класса Calculator
    {
        private string D; // Объявление приватной строки D
        private string N1; // Объявление приватной строки N1
        private bool n2; // Объявление приватной булевой переменной n2

        public Calculator() // Конструктор класса Calculator
        {
            D = ""; // Инициализация строки D
            N1 = ""; // Инициализация строки N1
            n2 = false; // Инициализация переменной n2
        }

        public void ButtonClick(object sender, RoutedEventArgs e, TextBox textBox) // Метод для обработки нажатия кнопки
        {
            if (n2) // Проверка значения переменной n2
            {
                n2 = false; // Установка значения переменной n2
                textBox.Text = "0"; // Установка текста в поле textBox
            }

            Button button = (Button)sender; // Приведение отправителя к типу Button
            if (textBox.Text == "0") // Проверка содержимого textBox
                textBox.Text = button.Content.ToString(); // Установка содержимого textBox
            else
                textBox.Text += button.Content.ToString(); // Добавление содержимого к textBox
        }

        public void EqualsClick(TextBox textBox) // Метод для обработки нажатия кнопки равно
        {
            double dn1, dn2, res; // Объявление числовых переменных
            res = 0; // Инициализация переменной res
            dn1 = Convert.ToDouble(N1); // Преобразование строки N1 в число
            dn2 = Convert.ToDouble(textBox.Text); // Преобразование содержимого textBox в число

            if (D == "+") // Проверка оператора сложения
            {
                res = dn1 + dn2; // Выполнение операции сложения
            }
            if (D == "-") // Проверка оператора вычитания
            {
                res = dn1 - dn2; // Выполнение операции вычитания
            }
            if (D == "X") // Проверка оператора умножения
            {
                res = dn1 * dn2; // Выполнение операции умножения
            }
            if (D == "/") // Проверка оператора деления
            {
                res = dn1 / dn2; // Выполнение операции деления
            }
            if (D == "%") // Проверка оператора процента
            {
                res = dn1 * dn2 / 100; // Вычисление процента
            }

            D = "="; // Установка оператора равно
            n2 = true; // Установка значения переменной n2
            textBox.Text = res.ToString(); // Установка результата в textBox
        }

        public void OperatorClick(object sender, TextBox textBox) // Метод для обработки нажатия кнопки оператора
        {
            Button button = (Button)sender; // Приведение отправителя к типу Button
            D = button.Content.ToString(); // Установка оператора
            N1 = textBox.Text; // Сохранение значения textBox в N1
            n2 = true; // Установка значения переменной n2
        }

        public void Clear(TextBox textBox) // Метод для очистки содержимого textBox
        {
            textBox.Text = "0"; // Установка текста в поле textBox
        }

        public void SquareRoot(TextBox textBox) // Метод для вычисления квадратного корня
        {
            double dn, res; // Объявление числовых переменных

            dn = Convert.ToDouble(textBox.Text); // Преобразование содержимого textBox в число
            res = Math.Sqrt(dn); // Вычисление квадратного корня
            textBox.Text = res.ToString(); // Установка результата в textBox
        }

        public void Square(TextBox textBox) // Метод для возведения числа в квадрат
        {
            double dn, res; // Объявление числовых переменных

            dn = Convert.ToDouble(textBox.Text); // Преобразование содержимого textBox в число
            res = Math.Pow(dn, 2); // Возведение числа в квадрат
            textBox.Text = res.ToString(); // Установка результата в textBox
        }
    }
}
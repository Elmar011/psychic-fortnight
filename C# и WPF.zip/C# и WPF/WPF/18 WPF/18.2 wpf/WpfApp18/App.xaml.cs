﻿using System.Windows; // подключаем пространство имен для работы с элементами пользовательского интерфейса Windows
using System.Windows.Controls; // подключаем пространство имен для работы с элементами управления в пользовательском интерфейсе

namespace CalculatorWPF // объявляем пространство имен
{
    public partial class MainWindow : Window // создаем класс MainWindow, который наследуется от класса Window
    {
        private Calculator calculator; // объявляем приватное поле calculator типа Calculator

        public MainWindow() // конструктор класса MainWindow
        {
            InitializeComponent(); // инициализируем компоненты окна
            calculator = new Calculator(); // создаем новый объект класса Calculator и присваиваем его полю calculator
        }

        private void Number_Click(object sender, RoutedEventArgs e) // метод для обработки клика по кнопке с цифрой
        {
            calculator.ButtonClick(sender, e, textBox); // вызываем метод ButtonClick объекта calculator, передавая в него параметры sender, e и textBox
        }

        private void Equals_Click(object sender, RoutedEventArgs e) // метод для обработки клика по кнопке равно
        {
            calculator.EqualsClick(textBox); // вызываем метод EqualsClick объекта calculator, передавая в него параметр textBox
        }

        private void Operator_Click(object sender, RoutedEventArgs e) // метод для обработки клика по кнопке оператора
        {
            calculator.OperatorClick(sender, textBox); // вызываем метод OperatorClick объекта calculator, передавая в него параметры sender и textBox
        }

        private void Clear_Click(object sender, RoutedEventArgs e) // метод для обработки клика по кнопке очистки
        {
            calculator.Clear(textBox); // вызываем метод Clear объекта calculator, передавая в него параметр textBox
        }

        private void SquareRoot_Click(object sender, RoutedEventArgs e) // метод для обработки клика по кнопке извлечения квадратного корня
        {
            calculator.SquareRoot(textBox); // вызываем метод SquareRoot объекта calculator, передавая в него параметр textBox
        }
    }
}
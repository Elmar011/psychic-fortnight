﻿using System;
using System.Text;
using System.Windows;

namespace EventLoggerApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LogEvents_Click(object sender, RoutedEventArgs e)
        {
            LogEvent("Button Clicked", e);

        }

        private void LogEvent(string eventName, RoutedEventArgs e)
        {
            string logText = $"{DateTime.Now} - {eventName}";

            if (e != null)
            {
                logText += $", OriginalSource: {e.OriginalSource}, Source: {e.Source}, RoutedEvent: {e.RoutedEvent}";
            }

            logText += Environment.NewLine;

            EventLogTextBox.AppendText(logText);
        }
    }
}

﻿using System;  // Подключение пространства имен System для доступа к базовым классам
using System.Windows;  // Подключение пространства имен System.Windows для работы с элементами пользовательского интерфейса
using System.Windows.Controls;  // Подключение пространства имен System.Windows.Controls для работы с элементами управления
using System.Windows.Media;  // Подключение пространства имен System.Windows.Media для работы с графическими объектами

namespace TextEditorApp  // Объявление пространства имен TextEditorApp
{
    public partial class MainWindow : Window  // Объявление класса MainWindow, который наследуется от класса Window
    {
        public MainWindow()  // Объявление конструктора класса MainWindow
        {
            InitializeComponent();  // Вызов метода InitializeComponent для инициализации компонентов окна
            Loaded += MainWindow_Loaded;  // Добавление обработчика события Loaded при загрузке окна
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)  // Объявление обработчика события Loaded
        {
            foreach (FontFamily fontFamily in Fonts.SystemFontFamilies)  // Перебор всех шрифтов в системе
            {
                Button button = new Button  // Создание новой кнопки
              
                {
                    Content = fontFamily.ToString(),  // Установка текста кнопки равным имени шрифта
                    FontFamily = fontFamily,  // Установка шрифта кнопки равным текущему шрифту
                    Margin = new Thickness(10),  // Установка отступа вокруг кнопки
                    Padding = new Thickness(10),  // Установка внутреннего отступа кнопки
                    
                };
                button.Click += FontButtonClick;  // Добавление обработчика события Click для кнопки

                FontButtonsPanel.Children.Add(button);  // Добавление кнопки в панель FontButtonsPanel
            }
        }

        private void FontButtonClick(object sender, RoutedEventArgs e)  // Объявление обработчика события Click для кнопки
        {
            Button button = (Button)sender;  // Приведение отправителя события к типу Button и сохранение в переменную button
            TextBlock.FontFamily = button.FontFamily;  // Установка шрифта TextBlock равным шрифту кнопки
        }
    }
}
// Комментарий: Класс MainWindow представляет основное окно приложения. В конструкторе происходит инициализация компонентов окна.
// В обработчике события Loaded добавляются кнопки для выбора шрифтов из списка системных шрифтов. Обработчик FontButtonClick устанавливает
// выбранный шрифт для TextBlock при клике на соответствующую кнопку.
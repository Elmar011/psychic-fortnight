﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;

namespace WpfMenuWithTextBoxDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // File Menu Handlers
        private void New_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = ""; // Clear TextBox
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                textBox.Text = System.IO.File.ReadAllText(openFileDialog.FileName);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                System.IO.File.WriteAllText(saveFileDialog.FileName, textBox.Text);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close(); // Close the application
        }

        // Edit Menu Handlers
        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            textBox.Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            textBox.Copy();
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            textBox.Paste();
        }

        // Context Menu Handlers
        private void TextBoxContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            // Enable/disable Cut, Copy, Paste menu items based on selection
            MenuItem cutMenuItem = (MenuItem)((ContextMenu)sender).Items[0];
            MenuItem copyMenuItem = (MenuItem)((ContextMenu)sender).Items[1];
            cutMenuItem.IsEnabled = textBox.SelectionLength > 0;
            copyMenuItem.IsEnabled = textBox.SelectionLength > 0;
            pasteContextMenuItem.IsEnabled = Clipboard.ContainsText();
        }

        private void TextBoxPreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Enable/disable Paste menu item based on clipboard content
            pasteContextMenuItem.IsEnabled = Clipboard.ContainsText();
        }
    }
}

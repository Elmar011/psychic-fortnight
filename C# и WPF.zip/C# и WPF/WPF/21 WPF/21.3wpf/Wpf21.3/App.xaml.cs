﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace LicenseKeyApp
{
    public partial class MainWindow : Window
    {
        public MainWindow() { InitializeComponent(); }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string licenseKey = txtLicenseKey.Text;

            if (licenseKey == "Trial")
            {
                fileMenu.Visibility = Visibility.Visible;
            }
            else if (licenseKey == "Pro")
            {
                editMenu.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Invalid license key. Please enter 'Trial' or 'Pro'.");
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = sender as MenuItem;
            MessageBox.Show($"'{menuItem.Header}' function has been executed.");
        }
    }
}
﻿// SimpleWindow.xaml.cs

using System.Windows;

namespace LoginApp
{
    public partial class SimpleWindow : Window
    {
        public SimpleWindow()
        {
            InitializeComponent();
        }
    }
}

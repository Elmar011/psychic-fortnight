﻿// PremiumWindow.xaml.cs

using System.Windows;

namespace LoginApp
{
    public partial class PremiumWindow : Window
    {
        public PremiumWindow()
        {
            InitializeComponent();
        }
    }
}

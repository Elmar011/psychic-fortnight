﻿// MainWindow.xaml.cs

using System;
using System.Windows;

namespace LoginApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Password;

            // Проверка логина и пароля
            bool isAuthenticated = Authenticate(username, password);

            if (isAuthenticated)
            {
                if (username == "premium")
                {
                    PremiumWindow premiumWindow = new PremiumWindow();
                    premiumWindow.Show();
                }
                else
                {
                    SimpleWindow simpleWindow = new SimpleWindow();
                    simpleWindow.Show();
                }

                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }

        private bool Authenticate(string username, string password)
        {
            // Проверяем, соответствует ли введенный логин и пароль премиум-пользователю
            if (username == "premium" && password == "premium_password")
                return true;
            else if (username == "user" && password == "password")
                return true;
            // Здесь вы можете добавить другие условия для аутентификации других пользователей, если необходимо
            else
                return false;
        }
    }
}

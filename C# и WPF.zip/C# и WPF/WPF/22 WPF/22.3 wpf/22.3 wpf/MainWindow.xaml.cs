﻿using System.Windows;

namespace UserRegistrationApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            // Validate user input
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtCity.Text) ||
                string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                txtValidationMessage.Text = "All fields are required.";
                return;
            }

            if (!int.TryParse(txtAge.Text, out int age) || age <= 0)
            {
                txtValidationMessage.Text = "Please enter a valid age.";
                return;
            }

            // If all validations pass, proceed with registration
            // Here you can add code to register the user
            MessageBox.Show("User registered successfully!");
        }
    }
}

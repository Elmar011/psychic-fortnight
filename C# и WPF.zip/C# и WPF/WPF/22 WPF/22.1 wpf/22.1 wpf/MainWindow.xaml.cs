﻿using System.Windows;

namespace LoginApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            // Получаем введенные логин и пароль
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            // Проверяем логин и пароль (в данном примере проверка просто по пустым полям)
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                // Если логин и пароль не пустые, можно выполнить дополнительную проверку
                // и выполнить соответствующие действия, например, открыть новое окно или выполнить вход
                MessageBox.Show("Login successful!");
            }
            else
            {
                MessageBox.Show("Please enter username and password.");
            }
        }
    }
}
